const oAPP = {
    onStart:function(){
        
    }    
    
};
 
//Device ready 
document.addEventListener('deviceready', onDeviceReady, false);
function onDeviceReady() {
    oAPP.onStart();
}