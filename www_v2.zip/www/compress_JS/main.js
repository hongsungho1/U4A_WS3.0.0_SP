let oAPP = {};
let oUI = {};

document.addEventListener('DOMContentLoaded', async function () { 

    //electron API 오브젝트 
    oAPP = parent.fn_getParent();

    //UI 생성 
    fn_CreateUI();

    
    //마우스 휠 ZOOM 이벤트 설정
    oAPP._scale = oAPP.WEBCONTENT.getZoomLevel(); 
    
    document.addEventListener('mousewheel', (ev) => {
              
        if (ev.ctrlKey) {
        
            oAPP._scale += ev.deltaY * -0.01;
            oAPP._scale = Math.min(Math.max(-10, oAPP._scale), 10);

            var oDOM = oUI.EDITOR.getDomRef();

            oDOM.style.zoom = oAPP._scale;

            //oAPP.WEBCONTENT.setZoomLevel(oAPP._scale);
        
        }

    });

    
});

/*================================================================ */
/* UI 생성 
/*================================================================ */
function fn_CreateUI(){

    jQuery.sap.require('sap.ui.codeeditor.CodeEditor');
    oUI.APP = new sap.m.App({autoFocus:false, busyIndicatorDelay:1,height:"100%",width:"100%", busy:true});
    oUI.APP.attachAfterNavigate((e)=>{  oUI.APP.invalidate();  });
    oUI.APP.addStyleClass('sapUiSizeCompact');

    //페이지 생성
    oUI.PAGE = new sap.m.Page({showHeader:true});
    oUI.APP.addPage(oUI.PAGE);


    //해더 영역 
    var oBarMain  = new sap.m.Bar();

    //js 파일 업로드
    oBarMain.addContentLeft(new sap.m.Button({icon:"sap-icon://upload", type:"Emphasized", text:"JS파일 선택(Upload)", press:()=>{

        let options = {
            // See place holder 1 in above image
            title : "js 파일 선택", 
            // See place holder 4 in above image
            filters :[
            {name: "js file ", extensions: ["JS","js"]}
            ],
            properties: []
        };

        //js 파일 선택
        var T_FILES = oAPP.remote.dialog.showOpenDialogSync(oAPP.remote.getCurrentWindow(), options);

        if(typeof T_FILES === "undefined"){ return; }
        if(T_FILES.length == 0){ return; }

        oAPP.fs.readFile(T_FILES[0], 'utf8', function (err,data) {
            if (err) {
              return console.log(err);
            }

            oUI.EDITOR.setValue(data);
            
       });



    }}));

    //js 파일 압축(compress)
    oBarMain.addContentLeft(new sap.m.Button({icon:"sap-icon://attachment-zip-file", type:"Critical", text:"js 파일 압축(compress)", press:()=>{
        
        //압축전 점검
        if(fn_chk_beforCompress() === "E"){return;}


        //질문팝업 메시지 
        fn_message("Q", "압축(compress) 진행?", (e)=>{

            if(e !== "YES"){ return; }

            var options = {
                // See place holder 1 in above image
                title : "다운로드 처리 폴더 선택", 
            
                // See place holder 2 in above image
                defaultPath : "",
            
                // See place holder 3 in above image
                buttonLabel : "선택",
            
                // See place holder 4 in above image
                filters :[
    
                ],
                properties: ['openDirectory','']
            };
    
            oAPP.remote.dialog.showOpenDialog(oAPP.remote.getCurrentWindow(), options).then((e)=>{ 
    
                //작업취소 
                if(e.canceled){ return; }

                debugger;

                //로딩바 실행 
                oUI.APP.setBusy(true);

                //JS DATA 압축
                var LS_RETURN = u4aJSCompress.minify(oUI.EDITOR.getValue());

                //다운로드 처리 명 + 경로 구성
                var LV_FILE_NAME = fn_random(20) + ".js";
                var LV_DOWN_PATH = oAPP.path.join(e.filePaths[0], LV_FILE_NAME);

                //다운로드 처리 
                try {
                    oAPP.fs.writeFileSync(LV_DOWN_PATH, LS_RETURN.code, 'utf-8');
                } catch (error) {
                    var LV_MSG = "다운로드 처리 과정에서 오류 발생 : " + error;
                    fn_message("E", LV_MSG, (e)=>{ oUI.EDITOR.focus(); oUI.APP.setBusy(false); });

                    return;
                    
                }
                

                //정상 처리 메시지
                fn_message("S", "처리 완료", (e)=>{ oUI.EDITOR.focus(); oUI.APP.setBusy(false); });


                //Download 폴더 open 
                oAPP.remote.shell.showItemInFolder(LV_DOWN_PATH);


                //debugger;

    
            });

        });

    }}));   


    oUI.PAGE.setCustomHeader(oBarMain);


    //코드 EDITOR 영역 생성
    oUI.EDITOR = new sap.ui.codeeditor.CodeEditor({type:"javascript", lineNumbers:true});
    oUI.PAGE.addContent(oUI.EDITOR);
    

    //Update UI( DOM 생성이후) 이벤트 핸들러 설정
    sap.ui.getCore().attachEvent(sap.ui.core.Core.M_EVENTS.UIUpdated, fn_UIUPdated);


    /*  최종 Dom 생성  */
    oUI.APP.placeAt("content","only");

}


/*================================================================ */
/* Update UI Callback 
/*================================================================ */
function fn_UIUPdated(){

    //Update UI 이벤트 핸들러 제거 
    sap.ui.getCore().detachEvent(sap.ui.core.Core.M_EVENTS.UIUpdated, fn_UIUPdated);

    //화면 활성 
    $( '#content' ).fadeIn(1500);

    //로딩바 제거 
    oUI.APP.setBusy(false);

}


/*================================================================ */
/* 메시지 처리
/*================================================================ */
function fn_message(S, M, CB){

    jQuery.sap.require('sap.m.MessageBox');

    var Licon;
    var T_action = [];

    switch (S) {
        case "S":
            Licon    = sap.m.MessageBox.Icon.SUCCESS;
            T_action = [sap.m.MessageBox.Action.OK];
            break;

        case "E":
            Licon    = sap.m.MessageBox.Icon.ERROR;
            T_action = [sap.m.MessageBox.Action.OK];
            break;

        case "W":
            Licon    = sap.m.MessageBox.Icon.WARNING;
            T_action = [sap.m.MessageBox.Action.OK];
            break;
    
        case "I":
            Licon    = sap.m.MessageBox.Icon.INFORMATION;
            T_action = [sap.m.MessageBox.Action.OK];
            break;

        case "Q":
            Licon    = sap.m.MessageBox.Icon.QUESTION;
            T_action = [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO];
            break;

        default:
            return;
            
    }

    sap.m.MessageBox.show(M, { title:"Confirm", icon: Licon, actions:T_action,onClose:(e)=>{ CB(e); }  });

}

/*================================================================ */
/* 압축전 점검
/*================================================================ */
function fn_chk_beforCompress(){

    var ret = "E";

    //입력값 누락
    var LV_VAL = oUI.EDITOR.getValue().replaceAll("\n", "");
    if(LV_VAL === ""){

        fn_message("E", "EDITOR 입력값 누락!!", (e)=>{ oUI.EDITOR.focus(); });
        return ret;

    }


    var LS_RETURN = u4aJSCompress.minify(oUI.EDITOR.getValue());

    if(LS_RETURN && LS_RETURN.error){
        var l = LS_RETURN.error;
        var LV_MSG = "js Compress중 오류발생\n" + "라인 : " +  l.line + "\n메시지 : " + l.message;

        fn_message("E", LV_MSG, (e)=>{ oUI.EDITOR.focus(); });
        return ret;

    }

    return "S";

}


/*================================================================ */
/* 랜덤키 생성
/*================================================================ */
function fn_random(length = 8){
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let str = '';
    
    for (let i = 0; i < length; i++) {
        str += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return str;
}