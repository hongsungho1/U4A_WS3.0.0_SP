let oAPP  = {};
let oUI   = {};
let ADMIN = {};

/*================================================================ */
/* 시작
/*================================================================ */
document.addEventListener('DOMContentLoaded', async function () { 

    //electron API 오브젝트 
    oAPP = parent.fn_getParent();

    //UI 생성 
    fn_CreateUI();

});


/*================================================================ */
/* UI 생성 
/*================================================================ */
function fn_CreateUI(){

    oUI.APP = new sap.m.App({autoFocus:false, busyIndicatorDelay:1,height:"100%",width:"100%", busy:true});
    oUI.APP.attachAfterNavigate((e)=>{  oUI.APP.invalidate();  });
    oUI.APP.addStyleClass('sapUiSizeCompact');

    //페이지 생성
    oUI.PAGE = new sap.m.Page({showHeader:false});
    oUI.APP.addPage(oUI.PAGE);
    
    var HBOX01 = new sap.m.HBox({width:"100%", renderType:"Bare"});
    oUI.PAGE.addContent(HBOX01);

    //============================================================================//
    // 상단 해더 영역 버젼 정보     
    //============================================================================// 
    var SIMPLEFORM01 = new sap.ui.layout.form.SimpleForm({breakpointL:1024,breakpointM:600,breakpointXL:1440,columnsL:3,columnsM:1,columnsXL:-1,editable:true,emptySpanL:0,emptySpanM:0,emptySpanS:0,emptySpanXL:-1,labelMinWidth:192,labelSpanL:4,labelSpanM:2,labelSpanS:12,labelSpanXL:-1,maxContainerCols:2,minWidth:-1});
        HBOX01.addItem(SIMPLEFORM01);

        //WS3.0 버젼 
        SIMPLEFORM01.addContent(new sap.m.Label({design:"Bold",text:"WS30 버젼"}));
        oUI.VERSN = new sap.tnt.InfoLabel({text:""});
        SIMPLEFORM01.addContent(oUI.VERSN);

        //Support Patch Level - 현재버젼
        SIMPLEFORM01.addContent(new sap.m.Label({design:"Bold",text:"Support Patch Level - current"}));
        oUI.SPLEV_C = new sap.m.Input({editable:false});
        SIMPLEFORM01.addContent(oUI.SPLEV_C);


        //Support Patch Level - 증가될 버젼
        SIMPLEFORM01.addContent(new sap.m.Label({design:"Bold",text:"Support Patch Level - update"}));
        oUI.SPLEV = new sap.m.MaskInput({mask:99999});
        SIMPLEFORM01.addContent(oUI.SPLEV);


    //============================================================================//
    //  README 영역 EDITOR
    //============================================================================// 
    var PANEL2 = new sap.m.Panel({expanded:true,headerText:"README notes",width:"100%", height:"370px"});
        oUI.PAGE.addContent(PANEL2);


        jQuery.sap.require('sap.ui.richtexteditor.RichTextEditor');

        oUI.RICHTEXTEDITOR1 = new sap.ui.richtexteditor.RichTextEditor({
            busyIndicatorDelay:1,
            width:"100%",
            editorType:"TinyMCE6",
            showGroupClipboard:true,
            showGroupStructure:true,
            showGroupFont:true,
            showGroupInsert:true,
            showGroupLink:true,
            showGroupUndo:true,
            change:function(e){ console.log(e); },
            beforeEditorInit:function (oEvent) {
                console.log(oEvent);
                tinymce.init({
                    selector: 'textarea',
                    width: "100%",
                    height: "300px",
                    //theme: 'modern',
                    plugins: 'fullscreen code media link table autolink codesample',
                    //plugins: 'paste emoticons lists fullscreen advlist image imagetools code media link colorpicker table textcolor textpattern autolink codesample preview',
                    toolbar: 'fullscreen bold italic strikethrough fontselect fontsizeselect forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat | undo redo styleselect codesample',
                    font_formats: 'Andale Mono=andale mono,times;Arial=arial,helvetica,sans-serif;Arial Black=arial black,avant garde;Book Antiqua=book antiqua,palatino;Comic Sans MS=comic sans ms,sans-serif;Courier New=courier new,courier;Georgia=georgia,palatino;Helvetica=helvetica;Impact=impact,chicago;Symbol=symbol;Tahoma=tahoma,arial,helvetica,sans-serif;Terminal=terminal,monaco;Times New Roman=times new roman,times;Trebuchet MS=trebuchet ms,geneva;Verdana=verdana,geneva;Webdings=webdings;Wingdings=wingdings,zapf dingbats',
                    fontsize_formats: '8pt 10pt 12pt 14pt 18pt 24pt 36pt',
                    menubar: false,
                    statusbar: false,
                    image_advtab: false,
                    paste_data_images: false,
                    init_instance_callback: function (editor) {

                    }
                });
            }
        });

        PANEL2.addContent(oUI.RICHTEXTEDITOR1);

        //tinyMCE.get()[0].getContent()

    //============================================================================//
    //  첨부 영역
    //============================================================================// 
    var PANEL_ATTCH = new sap.m.Panel({expanded:true,headerText:"Attachments - 반드시 소스 압축후 업로드 하시오!!",width:"100%"});
        oUI.PAGE.addContent(PANEL_ATTCH);

        var ATTCH_HBOX  = new sap.m.HBox();
        PANEL_ATTCH.addContent(ATTCH_HBOX);

        oUI.ATTCH_PATH  = new sap.m.Input({valueHelpOnly:true, width:"400px", placeholder:"PC 로컬 경로"});
        oUI.ATTCH_PATH.addStyleClass("sapUiSmallMarginBegin");
            ATTCH_HBOX.addItem(oUI.ATTCH_PATH);

        var ATTCH_BUT   = new sap.m.Button({text:"파일선택", 
                                            icon:"sap-icon://attachment-zip-file",
                                            type:"Emphasized", 
                                            press:()=>{
                                                //파일 선택 

                                                let options = {
                                                    // See place holder 1 in above image
                                                    title : "support path zip file 선택", 

                                                    // See place holder 4 in above image
                                                    filters :[
                                                     {name: 'ZIP', extensions: ['zip', 'ZIP']}
                                                    ],
                                                    properties: ['openFile','multiSelections']
                                                };
                                        
                                                let filePaths = oAPP.remote.dialog.showOpenDialogSync(oAPP.remote.getCurrentWindow(), options);
                                                    if(typeof filePaths === "undefined"){ sap.m.MessageToast.show("작업취소");  return; }

                                                    //필수표시 제거 
                                                    oUI.ATTCH_PATH.setValueState("None");

                                                    //파일 path 출력값 설정
                                                    oUI.ATTCH_PATH.setValue(filePaths[0]);

                                                    //input mode 잠금설정
                                                    fn_inputLock(oUI.ATTCH_PATH);

                                                    oUI.ATTCH_PATH.focus();
                                                

                                            }});

            ATTCH_BUT.addStyleClass("sapUiMediumMarginBegin");
            ATTCH_HBOX.addItem(ATTCH_BUT);

        
    //============================================================================//
    //  푸터 영역
    //============================================================================// 

    var FOOTER_TOOBAR = new sap.m.Toolbar();

    //상태 Status txt
    oUI.STATUS_TXT = new sap.m.Text({text:"준비"});
    FOOTER_TOOBAR.addContent(oUI.STATUS_TXT);

    //빈영역 삽입
    FOOTER_TOOBAR.addContent(new sap.m.ToolbarSpacer());

    //업데이트 처리
    FOOTER_TOOBAR.addContent(new sap.m.Button({text:"support patch", icon:"sap-icon://shipping-status",type:"Emphasized", press:()=>{

        //필수항목 점검 및 값 점검
        if(fn_CHK_SUPPORT_PATCH() === "E"){ return; }


        //처리전 질문 팝업
        fn_message("Q", "support patch 을(를) 진행하시겠습니까?", (e)=>{

            if(e !== "YES"){ sap.m.MessageToast.show("작업취소"); return; }

            //Support Patch 시작
            fn_SUPPORT_PATCH();

        });
    
    }}));


    oUI.PAGE.setFooter(FOOTER_TOOBAR);


    //Update UI( DOM 생성이후) 이벤트 핸들러 설정
    sap.ui.getCore().attachEvent(sap.ui.core.Core.M_EVENTS.UIUpdated, fn_UIUPdated);


    /*  최종 Dom 생성  */
    oUI.APP.placeAt("content","only");


}

/*================================================================ */
/* Update UI Callback 
/*================================================================ */
async function fn_UIUPdated(){

    //Update UI 이벤트 핸들러 제거 
    sap.ui.getCore().detachEvent(sap.ui.core.Core.M_EVENTS.UIUpdated, fn_UIUPdated);

    //화면 활성 
    $( '#content' ).fadeIn(1500);

    //초기 Data 설정
    await fn_initData();

    //support path verstion 얻기 
    var LS_RET = await fn_getVerstion();
    if(LS_RET.RETCD === "E"){

        //로딩바 제거 
        oUI.APP.setBusy(false);

        //메시지 처리
        fn_message("E",LS_RET.RTMSG, ()=>{
            oAPP.remote.getCurrentWindow().close();
        });

        return;

    }

    //로딩바 제거 
    oUI.APP.setBusy(false);


    //첨부등록 input 영역 readonly 처리 
    //오류사항일 경우 오류표시를 하기 위함
    fn_inputLock(oUI.ATTCH_PATH);


}

/*================================================================ */
/* Time stemp 
/*================================================================ */
function fn_timeStemp(T=false){
        //T <-- 현재 시간 포함 여부

        //오늘 일자 
        let today = new Date();
        let year = today.getFullYear();   // 년도
        let month = today.getMonth() + 1; // 월
        let date = today.getDate();       // 날짜
        let day = today.getDay();         // 요일

        //문자열로 변경 
        year  = year.toString();
        month = month.toString().padStart(2,0);
        date  = date.toString().padStart(2,0);
        day   = day.toString();

        if(T){
            let hours = today.getHours().toString().padStart(2,0);      // 시
            let minutes = today.getMinutes().toString().padStart(2,0);  // 분
            let seconds = today.getSeconds().toString().padStart(2,0);  // 초
            return year + "." + month + "." + date + " / " + hours + ":" + minutes + ":" + seconds;
        }
    
    return year + "." + month + "." + date;

}



/*================================================================ */
/* support path verstion 얻기 
/*================================================================ */
async function fn_getVerstion(){
    return new Promise( async (resolve, reject) => {

        let oformData = new FormData();
        oformData.append('sap-user', ADMIN.SAP.ID);
        oformData.append('sap-password', ADMIN.SAP.PW);
        oformData.append('PRCCD', '01');
        
        var xhttp = new XMLHttpRequest();
        xhttp.onload  = (e)=>{ 
            debugger;
            if(e.target.status != 200 || e.target.response === ""){
                resolve({RETCD:"E",RTMSG:"버젼 정보 추출시 SAP 서버 통신 실패!! \n 관리자 문의 \n 현재창 종료 합니다"});
                return;
            }

            try {
                var LS_DATA = JSON.parse(e.target.response);
            } catch (err) {
                resolve({RETCD:"E",RTMSG:"버젼 정보 추출시 SAP 서버 통신 실패!! \n 관리자 문의 \n 현재창 종료 합니다"});
                return;
                
            }

            if(LS_DATA.RETCD === "E"){
                resolve({RETCD:"E",RTMSG:LS_DATA.RTMSG});
                return;
            }

            //WS3.0 버젼
            oUI.VERSN.setText(LS_DATA.VERSN);

            //Support Patch Level - 현재
            oUI.SPLEV_C.setValue(LS_DATA.SPLEV);

            //Support Patch Level - 업데이트 대상
            var LV_SPLEV = LS_DATA.SPLEV + 1;
            oUI.SPLEV.setValue(LV_SPLEV);

            resolve({RETCD:"S",RTMSG:""}); 

        };

        xhttp.onerror = (e)=>{ 
            resolve({RETCD:"E",RTMSG:"버젼 정보 추출시 SAP 서버 통신 실패!! \n 관리자 문의 \n 현재창 종료 합니다"}); 

        };  

        xhttp.open("POST", ADMIN.SAP.URL, true);
        xhttp.send(oformData);

    });
}

/*================================================================ */
/* 초기 Data 설정 
/*================================================================ */
async function fn_initData(){
    return new Promise( async (resolve, reject) => {

        //sap config
        ADMIN.SAP = {};
        ADMIN.SAP.ID  = "shhong";
        ADMIN.SAP.PW  = "2wsxzaq1!";
        ADMIN.SAP.URL = "http://u4arnd.com:8000/zu4a_rnd/WS30_SUPPORT_PATCH_UPLOAD";

        if(oAPP.remote.app.isPackaged){
            ADMIN.SAP.ID  = "U4AIDE";
            ADMIN.SAP.PW  = "$u4aRnd$";
         
        }

        //git config
        ADMIN.GIT = {};
        ADMIN.GIT.AUTH = "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";

        if(oAPP.remote.app.isPackaged){
            ADMIN.GIT.AUTH = "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";          
        }

        ADMIN.BASE_PATH = "https://api.github.com/repos/hongsungho1/U4A_WS3.0.0_SP";

        resolve({RETCD:"S",RTMSG:""});

    });
}


/*================================================================ */
/* 메시지 처리
/*================================================================ */
function fn_message(S, M, CB){

    jQuery.sap.require('sap.m.MessageBox');

    var Licon;
    var T_action = [];

    switch (S) {
        case "S":
            Licon    = sap.m.MessageBox.Icon.SUCCESS;
            T_action = [sap.m.MessageBox.Action.OK];
            break;

        case "E":
            Licon    = sap.m.MessageBox.Icon.ERROR;
            T_action = [sap.m.MessageBox.Action.OK];
            break;

        case "W":
            Licon    = sap.m.MessageBox.Icon.WARNING;
            T_action = [sap.m.MessageBox.Action.OK];
            break;
    
        case "I":
            Licon    = sap.m.MessageBox.Icon.INFORMATION;
            T_action = [sap.m.MessageBox.Action.OK];
            break;

        case "Q":
            Licon    = sap.m.MessageBox.Icon.QUESTION;
            T_action = [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO];
            break;

        default:
            return;
            
    }

    sap.m.MessageBox.show(M, { title:"Confirm", icon: Licon, actions:T_action,onClose:(e)=>{ CB(e); }  });

}

/*================================================================ */
/* INPUT LOCK 설정 - UI INPUT 으로 파생된것만 가능!!
/*================================================================ */
function fn_inputLock(oUI){
    setTimeout(() => {
        oUI.getDomRef().querySelector("input").setAttribute("readonly", "readonly");
    }, 0);
    
}

/*================================================================ */
/* 랜덤키
/*================================================================ */
function fn_random(length = 15){

    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let str = '';

    for (let i = 0; i < length; i++) {
    str += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    return str;

}


/*================================================================ */
/* Support Patch 처리 전 점검
/*================================================================ */
function fn_CHK_SUPPORT_PATCH(){

    //필수 표시 제거
    oUI.SPLEV.setValueState("None");
    oUI.ATTCH_PATH.setValueState("None");

    //input 잠금 - path
    fn_inputLock(oUI.ATTCH_PATH);

    //현재 패치번호 및 증가 패치번호 
    var LV_SPLEV_C = Number(oUI.SPLEV_C.getValue());

    var LV_SPLEV = oUI.SPLEV.getValue().replace(/[^0-9]/g, "");
        LV_SPLEV = Number(LV_SPLEV);

    //증가 패치번호에 값이 없다면 ..
    if(LV_SPLEV == 0){
        oUI.SPLEV.setValueState("Error");
        sap.m.MessageToast.show("필수항목 값 누락!!");
        return "E";
    }

    //증가 패치번호가 증가전 패치번호보다 작다면..
    if(LV_SPLEV <= LV_SPLEV_C){
        oUI.SPLEV.setValueState("Error");
        sap.m.MessageToast.show("증가 패치번호가 이전 패치번호보다 작을수 없습니다!!");
        return "E";
    }    

    //README NOTE
    if(tinyMCE.get()[0].getContent() === ""){
        sap.m.MessageToast.show("NOTE 입력값 누락!!!");
        return "E";
    };

    //파일 경로
    if(oUI.ATTCH_PATH.getValue() === ""){

        oUI.ATTCH_PATH.setValueState("Error");

        //input 잠금 - path
        fn_inputLock(oUI.ATTCH_PATH);

        oUI.ATTCH_PATH.focus();

        sap.m.MessageToast.show("파일 경로 을(를) 지정하시오!!!");

        return "E";
    };

  
    //파일 경로 정합성 점검
    var IS_FILE = oAPP.fs.existsSync(oUI.ATTCH_PATH.getValue());
    if(!IS_FILE){

        oUI.ATTCH_PATH.setValueState("Error");

        //input 잠금 - path
        fn_inputLock(oUI.ATTCH_PATH);

        oUI.ATTCH_PATH.focus();

        sap.m.MessageToast.show("파일 경로 을(를) 확인하세요 \n  파일이 존재하지않습니다.");

        return "E";

    }


}


/*================================================================ */
/* Support Patch 시작
/*================================================================ */
async function fn_SUPPORT_PATCH(){

    //상태 Status text 설정
    oUI.STATUS_TXT.setText("진행중");

    //로딩바 설정
    oUI.APP.setBusy(true);
 
    /* 임시 주석!!!!!!!!!!!!!
 
    //1. GIT 이전 패치정보 추출
    var LS_RET01 = await fn_GET_OLD_SUPPORT_PATCH_GIT();
    if(LS_RET01.RETCD === "E"){

        //상태 Status text 설정
        oUI.STATUS_TXT.setText("준비");

        //로딩바 해제
        oUI.APP.setBusy(false);

        fn_message("E", LS_RET01.RTMSG,()=>{});
        return;
    }


    //2. NAS file 전송 - 이전 패치정보  
    var LS_RET02 = await fn_SUPPORT_PATCH_NAS(LS_RET01.T_FILE_INFO);
    if(LS_RET02.RETCD === "E"){

        //상태 Status text 설정
        oUI.STATUS_TXT.setText("준비");

        //로딩바 해제
        oUI.APP.setBusy(false);

        fn_message("E", LS_RET02.RTMSG,()=>{});
        return;
    }


    //3. GIT 이전 패치 file 버젼 삭제 
    var LS_RET03 = await fn_DEL_OLD_SUPPORT_PATCH(LS_RET01.T_FILE_INFO);
    if(LS_RET03.RETCD === "E"){

        //상태 Status text 설정
        oUI.STATUS_TXT.setText("준비");

        //로딩바 해제
        oUI.APP.setBusy(false);

        fn_message("E", LS_RET03.RTMSG,()=>{});
        return;
    }


    //4. GIT file 전송
    var LS_RET04 = await fn_SUPPORT_PATCH_GIT();
    if(LS_RET04.RETCD === "E"){

        //상태 Status text 설정
        oUI.STATUS_TXT.setText("준비");

        //로딩바 해제
        oUI.APP.setBusy(false);

        fn_message("E", LS_RET04.RTMSG,()=>{});
        return;
    }
    
    임시 주석 !!!!!
    */

    //SAP file 전송
    var LS_RET05 = await fn_SUPPORT_PATCH_SAP();

    if(LS_RET05.RETCD === "E"){

        //상태 Status text 설정
        oUI.STATUS_TXT.setText("준비");

        //로딩바 해제
        oUI.APP.setBusy(false);

        fn_message("E", LS_RET05.RTMSG,()=>{});
        return;
    }


    //상태 Status text 설정
    oUI.STATUS_TXT.setText("준비");

    //로딩바 해제
    oUI.APP.setBusy(false);

}

/*================================================================ */
/* GIT 이전 패치정보 추출
/*================================================================ */
async function fn_GET_OLD_SUPPORT_PATCH_GIT(){
    return new Promise( async (resolve, reject) => {
 
        //상태 Status text 설정
        oUI.STATUS_TXT.setText("GIT 이전 패치정보 추출중..");

        const octokit = new oAPP.Octokit({ auth:ADMIN.GIT.AUTH });

        //GIT 시작 Content Info 정보 얻기
        try {

            var ROOT = await octokit.request('GET ' + ADMIN.BASE_PATH + '/contents', {
                owner: 'OWNER',
                repo: 'REPO',
                path: 'PATH'
        
            });

        } catch (err) {
            resolve({RETCD:"E", RTMSG:"GIT 서비스 통신 오류 발생 \n 관리자에게 문의바람!!"});
            return;
            
        }

        //이전 패치 존재여부 점검
        var LV_FIND_CNT = 0;
        for (var i = 0; i < ROOT.data.length; i++) {
            if(ROOT.data[i].name === "README.md"){ LV_FIND_CNT++; }
            if(ROOT.data[i].name === "latest.json"){ LV_FIND_CNT++; } 

        }

        //이전 패치 정보 누락일 경우 
        if(LV_FIND_CNT < 2){
            resolve({RETCD:"W", RTMSG:"GIT 이전 패치정보 없슴!!"});
        }


        //[펑션] File 추출
        async function lfn_getFile(LS_INFO){
            return new Promise( async (res, rej) => {

                try {
                    var data = await octokit.request('GET '+ LS_INFO.download_url, {owner: 'OWNER'});
                } catch (err) {
                    res("E");
                    return;
                    
                }

                res(data);

            });
        }


        //이전 패치 파일 추출
        var LT_INFO = [];
        for (var i = 0; i < ROOT.data.length; i++) {

            //File 추출
            var LS_DATA = await lfn_getFile(ROOT.data[i]);
            if(LS_DATA === "E"){
                resolve({RETCD:"E", RTMSG:"GIT 이전 패치 파일 추출하는동안 오류 발생 관리자에게 문의!!"});
                return;
                break;
            }

            var LS_INFO   = {};
            LS_INFO.attr  = JSON.parse(JSON.stringify(ROOT.data[i]));
            LS_INFO.file  = LS_DATA; 

            LT_INFO.push(LS_INFO);

        }

        resolve({RETCD:"S", RTMSG:"", T_FILE_INFO:LT_INFO});

    });
}


/*================================================================ */
/* NAS file 전송 - 이전 패치정보  
/*================================================================ */
async function fn_SUPPORT_PATCH_NAS(T_FILE_INFO){
    return new Promise( async (resolve, reject) => {

        if(typeof T_FILE_INFO === "undefined"){
            resolve({RETCD:"W", RTMSG:""});
            return;
        }

        //상태 Status text 설정
        oUI.STATUS_TXT.setText("NAS 서버에 이전 패치정보 file 전송중..");

        var LS_LATEST = undefined;

        //임시 폴더 생성
        var LV_FOLD_PATH = oAPP.path.join(oAPP.resourcesPath, fn_random(30));
        oAPP.fs.mkdirSync(LV_FOLD_PATH);

        for (let i = 0; i < T_FILE_INFO.length; i++) {

            var LS_FILE_INFO    = T_FILE_INFO[i];
            var LV_CONTENT_TYPE = LS_FILE_INFO.file.headers["content-type"];
            var LV_FILE_NAME    = LS_FILE_INFO.attr.name;
            var LV_FILE_TYPE    = typeof LS_FILE_INFO.file.data;
            var LV_DOWN_PATH    = oAPP.path.join(LV_FOLD_PATH, LV_FILE_NAME);

            switch (LV_FILE_TYPE) {
                case "string":
                    try {
                        oAPP.fs.writeFileSync(LV_DOWN_PATH , LS_FILE_INFO.file.data, 'utf-8');
                    } catch (err) {
                        resolve({RETCD:"E", RTMSG:"이전 패치 파일에 문제가 존재합니다!!"});
                        return;
                    }
                    
                    break;

                case "object":
                    try {
                        oAPP.fs.writeFileSync(LV_DOWN_PATH, oAPP.Buffer.from(LS_FILE_INFO.file.data), 'binary');
                    } catch (err) {
                        resolve({RETCD:"E", RTMSG:"이전 패치 파일에 문제가 존재합니다!!"});
                        return;
                    }
                    
                    break;

                default:
                    break;

            }

            //패치 버젼 파일
            if(LV_FILE_NAME === "latest.json"){
                LS_LATEST = JSON.parse(LS_FILE_INFO.file.data);

            }

        }

        //패치 버젼 파일이 누락시!!
        if(typeof LS_LATEST === "undefined"){
            resolve({RETCD:"E", RTMSG:"GIT 이전 패치 버젼(latest) 파일 정보가 존재하지않습니다 관리자에게 문의!!"});
            return;

        }

        //NAS 파일 전송
        const SSH = new oAPP.NodeSSH();
        const Lpassword = '#u4aRnd$';
        var ssh = await SSH.connect({
            host: 'u4arnd.iptime.org',
            username: 'u4arnd',
            port: 9541,
            password : Lpassword,
            tryKeyboard: true,
        });

        
        //폴더 TO 폴더 - 파일 전송
        var NAS_PATH = "/mnt/Data/U4ARND/u4arnd/04. U4A WS3.0/03. U4A_WS_support_package/" + LS_LATEST.VERSN + "_" + LS_LATEST.SPLEV; 
        await ssh.putDirectory(LV_FOLD_PATH, NAS_PATH, {recursive: true});

        //NAS 연결 종료
        ssh.dispose();

        //테스트 모드일 경우는 폴더를 삭제 않하고 폴더를 수행한다 
        //패키징 상태일 경우는 폴더를 삭제함 - 임시폴더
        if(!oAPP.remote.app.isPackaged){
            oAPP.remote.shell.showItemInFolder(LV_FOLD_PATH);

        }else{
            //폴더 삭제
            try { oAPP.fs.rmdirSync(LV_FOLD_PATH, { recursive: true, force: true }); } catch (err) {}
            
        }


        resolve({RETCD:"S", RTMSG:""});


    });
}


/*================================================================ */
/* GIT 이전 패치 file 버전 삭제 
/*================================================================ */
async function fn_DEL_OLD_SUPPORT_PATCH(T_FILE_INFO){
    return new Promise( async (resolve, reject) => {

        if(typeof T_FILE_INFO === "undefined"){
            resolve({RETCD:"W", RTMSG:""});
            return;
        }

        //상태 Status text 설정
        oUI.STATUS_TXT.setText("GIT 이전 패치 file 버전 삭제");

        const octokit = new oAPP.Octokit({ auth:ADMIN.GIT.AUTH });

        for (let i = 0; i < T_FILE_INFO.length; i++) {
            var LS_FILE_INFO = T_FILE_INFO[i];

            try {

                await octokit.request('DELETE ' + ADMIN.BASE_PATH + '/contents/' + LS_FILE_INFO.attr.name, {
                    owner: 'OWNER',
                    repo: 'REPO',
                    path: 'PATH',
                    message: 'Remove previous version of WS3.0 support patch',
                    committer: {
                      name: 'U4A IDE',
                      email: 'https://www.u4ainfo.com'
                    },
                    sha: LS_FILE_INFO.attr.sha 
                  
                });                

            } catch (err) {
                resolve({RETCD:"E", RTMSG:"이전 패치 파일을 \n 삭제하는 과정에서 문제발생!! \n 관리자에게 문의바람!!"});
                return;
                
            }
            
        }

        resolve({RETCD:"S", RTMSG:""});

    });
}


/*================================================================ */
/* GIT file 전송
/*================================================================ */
async function fn_SUPPORT_PATCH_GIT(){
    return new Promise( async (resolve, reject) => {

        //상태 Status text 설정
        oUI.STATUS_TXT.setText("GIT file 전송중...");

        const octokit = new oAPP.Octokit({ auth:ADMIN.GIT.AUTH });

        //1. latest data 
        var LS_LATEST = {};
            LS_LATEST.VERSN = oUI.VERSN.getText();  //WS3.0 버젼 
            LS_LATEST.SPLEV = oUI.SPLEV.getValue().replace(/[^0-9]/g, ""); //WS3.0 패치 증가 버전

        try {    

            var LV_MSG = 'new support patch - latest / ' + fn_timeStemp(true);
            await octokit.request('PUT ' + ADMIN.BASE_PATH + '/contents/' + 'latest.json', {
                owner: 'OWNER',
                repo: 'REPO',
                path: 'PATH',
                message: LV_MSG,
                committer: {
                    name: 'U4A IDE',
                    email: 'https://www.u4ainfo.com'
                },
                content: oAPP.Buffer.from(JSON.stringify(LS_LATEST), "utf8").toString('base64') //값 base64 encode 

            });
        } catch (err) {
            resolve({RETCD:"E", RTMSG:"패치 파일(latest.json) \n 생성 과정에서 문제발생!! \n 관리자에게 문의바람!!"});
            return;
            
        }

        //2. README.md 본문 설명 
        try {
            var LV_MSG = 'new support patch - README / ' + fn_timeStemp(true);
            await octokit.request('PUT ' + ADMIN.BASE_PATH + '/contents/' + 'README.md', {
                owner: 'OWNER',
                repo: 'REPO',
                path: 'PATH',
                message: LV_MSG,
                committer: {
                    name: 'U4A IDE',
                    email: 'https://www.u4ainfo.com'
                },
                content: oAPP.Buffer.from(tinyMCE.get()[0].getContent(), "utf8").toString('base64') //값 base64 encode 
    
            });           

        } catch (err) {
            resolve({RETCD:"E", RTMSG:"패치 파일(README.md) \n 생성 과정에서 문제발생!! \n 관리자에게 문의바람!!"});
            return;
        }



        //3. 패치 소스 Data 
        try {
            var LV_MSG = 'new support patch - source data file / ' + fn_timeStemp(true);
            var LV_CONTENT = oAPP.fs.readFileSync(oUI.ATTCH_PATH.getValue() , 'base64');
            await octokit.request('PUT ' + ADMIN.BASE_PATH + '/contents/' + oAPP.path.basename(oUI.ATTCH_PATH.getValue()), {
                owner: 'OWNER',
                repo: 'REPO',
                path: 'PATH',
                message: LV_MSG,
                committer: {
                    name: 'U4A IDE',
                    email: 'https://www.u4ainfo.com'
                },
                content: LV_CONTENT //값 base64 encode 
    
            });        
                
        } catch (err) {
            resolve({RETCD:"E", RTMSG:"패치 파일(소스 Data zip) \n 생성 과정에서 문제발생!! \n 관리자에게 문의바람!!"});
            return;            
        }


        resolve({RETCD:"S", RTMSG:""});


    });
}

/* ============================================================= */
// [펑션] File Stream 분할 
/* ============================================================= */
async function fn_FileStreamSplit(PATH){
    return new Promise((resolve, rejH) => {
        debugger;
        var T_FILE_BUFF = [];

        var stream = oAPP.fs.createReadStream(PATH, {
            //highWaterMark: 1000000 // 스트림의 크기를 8바이트로 지정, 8글자씩 읽어온다.  기본값 64 kbytes
        });

        stream.on('data', function(data) {
            T_FILE_BUFF.push(data);

        });

        // 4. 데이터 전송이 완료되면 end 이벤트 발생
        stream.on('end', function () {
            console.log("END");
            resolve({RETCD:"S", RTMSG:"", T_FILE_BUFF:T_FILE_BUFF});
           
        });
    
        // 5. 스트림도중 에러 발생시 error 이벤트 발생
        stream.on('error', function(err) {
            console.log("오류 : " + err);
            resolve({RETCD:"E", RTMSG:"파일 분할 처리시 오류가 발생하였습니다."});

        });

    });
    
}

/*================================================================ */
/* SAP file 전송
/*================================================================ */
async function fn_SUPPORT_PATCH_SAP(){
    return new Promise( async (resolve, reject) => {

        //1. latest data 
        var LS_LATEST = {};
            LS_LATEST.VERSN = oUI.VERSN.getText();  //WS3.0 버젼 
            LS_LATEST.SPLEV = oUI.SPLEV.getValue().replace(/[^0-9]/g, ""); //WS3.0 패치 증가 버전

        
        //2   File Stream 분할 
        var retSTREAM = await fn_FileStreamSplit(oUI.ATTCH_PATH.getValue());

        debugger;

        resolve({RETCD:"S", RTMSG:""});
        
    });
}