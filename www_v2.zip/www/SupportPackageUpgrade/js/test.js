/* 
 기능 테스트 메모
*/


var URL = "http://u4arnd.com:8000/zs1?sap-user=shhong&sap-password=2wsxzaq1!";


const { Octokit } = oAPP.remote.require("@octokit/core");
const octokit = new Octokit({ auth:'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' });



//*[시작] =========================================================
//git sp 시작 폴더 정보 얻기 
//* =========================================================
var ROOT = await octokit.request('GET https://api.github.com/repos/hongsungho1/U4A_WS3.0.0_SP/contents/', {
        owner: 'OWNER',
        repo: 'REPO',
        path: 'PATH'

    });
//*[종료] =========================================================

//*[시작]=========================================================
// 파일 config 정보 read  
//* =========================================================
var latest = ROOT.data.filter(e=> e.name === "latest.json");
//*[종료] =========================================================



//*[시작]=========================================================
//content 얻기
//상위에서 얻은 ROOT.download_url <-- 통해 아래와 같이 Data 추출  
var data = await octokit.request('GET https://raw.githubusercontent.com/hongsungho1/U4A_WS3.0.0_SP/main/1.zip?token=AHV2RIMABMTG6YG76CTVK5LEA2Q36', {
  owner: 'OWNER'

});

//data.content-type <-- "application/zip"
//data.content-length <-- "크기"

//*[종료] =========================================================


//*[시작]=========================================================
//content 삭제
//상위에서 얻은 array 에 특정라인에 ROOT.data[0].sha <-- 취득
//1.zip <-- 상위에서 얻은 ROOT.data[0].path
await octokit.request('DELETE https://api.github.com/repos/hongsungho1/U4A_WS3.0.0_SP/contents/1.zip', {
  owner: 'OWNER',
  repo: 'REPO',
  path: 'PATH',
  message: 'SHHONG',
  committer: {
    name: 'Monalisa Octocat',
    email: 'octocat@github.com'
  },
  sha: '8a22dd856f9833c37f0dedfb44bd969ad7304ca2' //ROOT.data[0].sha

});
//*[종료] =========================================================


//*[시작]=========================================================
// content 추가 

//로컬 디렉토리에 파일 read 
var data = oAPP.fs.readFileSync('D:\\DOWNLOAD\\fld01.zip' , 'base64');

//git content 디렉토리에 전송 
await octokit.request('PUT https://api.github.com/repos/hongsungho1/U4A_WS3.0.0_SP/contents/fld01.zip', {
  owner: 'OWNER',
  repo: 'REPO',
  path: 'PATH',
  message: 'my commit message',
  committer: {
    name: 'Monalisa Octocat',
    email: 'octocat@github.com'
  },
  content: data //값 base64 encode 

});

//*[종료] =========================================================


//*[시작]=========================================================
// content pc 다운로드 
//npm install arraybuffer-to-buffer <-- 설치

var arrayBufferToBuffer = require('arraybuffer-to-buffer');

//data 추출후
var data = await octokit.request('GET https://raw.githubusercontent.com/hongsungho1/U4A_WS3.0.0_SP/main/1.zip?token=AHV2RIMABMTG6YG76CTVK5LEA2Q36', {
  owner: 'OWNER'

});

data.status  = 0; // 응답 상태코드
data.headers = {};// 응답 해더


//arraybuff to bin 
var bin = arrayBufferToBuffer(data.data);

try {
    oAPP.fs.writeFileSync("D:\\DOWNLOADdsdsdsd\\zzzzzz.zip", b, 'binary');  
} catch (error) {
    
}




//*[종료] =========================================================

