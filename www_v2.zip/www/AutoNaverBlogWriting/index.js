
let oWEBVIEW = document.createElement("webview");
oWEBVIEW.setAttribute("id", "mainFRAME");
oWEBVIEW.setAttribute("src", "https://blog.naver.com/alke?Redirect=Write");
oWEBVIEW.setAttribute("preload", "preload.js");
oWEBVIEW.setAttribute("partition", gn_random());
oWEBVIEW.setAttribute("sandbox", "false");
oWEBVIEW.setAttribute("enableremotemodule", "true");
oWEBVIEW.setAttribute("guestinstance", "3");

oWEBVIEW.addEventListener('dom-ready', async () => {

    oWEBVIEW.nodeintegration = true;       //require와 process 객체같은 node.js API를
    //oWEBVIEW.plugins = true;             // webview 내부에서 브라우저 플러그인을 사용할 수 있습니다.
    oWEBVIEW.disablewebsecurity = true;    //페이지의 웹 보안을 해제합니다.
    //oWEBVIEW.guestinstance = 1;
    //oWEBVIEW.sandbox = false;
    oWEBVIEW.contextIsolation = false;

    oWEBVIEW.nativeWindowOpen = true;

    //Webview 콘솔창 실행 
    if(!oAPP.remote.app.isPackaged){
        oWEBVIEW.openDevTools();           

    }


    //시작
    fn_start();

});


document.body.append(oWEBVIEW);



/*===================================================================*/
// 내부 사용 펑션 선언 
/*===================================================================*/


//랜덤키
function gn_random(length = 15){

    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let str = '';

    for (let i = 0; i < length; i++) {
    str += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    return str;

}



//시작
async function fn_start(){
    

            //번역 대상 text 전송
            var LV_JS   = '(function(){'
            + 'try {'
            + 'var ss = document.getElementById("mainFrame").contentWindow.document.getElementsByClassName("se-section")[0];'
            + 'console.log(ss);'
            + '} catch (e) {}'
            + '})();';

            await oWEBVIEW.executeJavaScript(LV_JS , true);  
    



}