const { contextBridge, ipcRenderer } = require("electron");


/* ========================================================= */
//  WEBVIEW 에 load 영역에서 아래영역으로 호출할수있음
/* ========================================================= */
contextBridge.exposeInMainWorld(
    "U4A", {
        send: (channel, data) => {
            ipcRenderer.sendToHost(channel, data);

        }
    }

);
