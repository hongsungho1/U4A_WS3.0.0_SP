let oUI5 = {};

const oAPP = {
    onStart:function(){
        this.remote = require('@electron/remote');
	    this.remote.nativeTheme.themeSource = "dark";
        this.ipcMain = this.remote.require('electron').ipcMain;
        this.ipcRenderer = require('electron').ipcRenderer;
        this.fs = this.remote.require('fs');
        this.path = this.remote.require('path');
        this.__dirname = __dirname;


		this.onCompress_JS();
        
    
    },
    
/* =========================================================================== */    
// js 파일 수정후 압축 화면 호출
/* =========================================================================== */       
    onCompress_JS : ()=>{

        if(typeof oUI5._win09 !== "undefined"){ return; }


		var op = {
			"height": 800,
			"width": 1000,
			"modal": false,
			"show": false,
			"minHeight":280,
			"minWidth":700,
			"resizable": true,
			"skipTaskbar": true,
			"icon": oAPP.path.join(oAPP.__dirname, 'img/logo.png'),
			"title":"JS file 수정 및 압축(compress)",
			"autoHideMenuBar": true,
			"partition": lfn_random(70), 
			"parent": oAPP.remote.getCurrentWindow(), 
			"webPreferences":{
				"devTools": true,
				"nodeIntegration": true,
				"contextIsolation": false,
				"nativeWindowOpen": true,
				"webSecurity": false,
				"sandbox": false
			}
		   
		};

		oAPP.remote.getCurrentWindow().webContents.closeDevTools();
		oUI5._win09 = new oAPP.remote.BrowserWindow(op);
		oUI5._win09.loadURL(`file://${oAPP.__dirname}/compress_JS/index.html`); 
		oAPP.remote.require('@electron/remote/main').enable(oUI5._win09.webContents);
		
		oUI5._win09.on('close', function(e){
            delete oUI5._win09;
			oAPP.remote.getCurrentWindow().close();
		
    	});

		oUI5._win09.webContents.on('did-finish-load', ()=> {
			oUI5._win09.show();

			if(!oAPP.remote.app.isPackaged){
				oUI5._win09.webContents.openDevTools();
			}
			
		});


    }
    
};

//Device ready 
document.addEventListener('deviceready', onDeviceReady, false);
function onDeviceReady() {
    oAPP.onStart();
}



//랜덤키 생성
function lfn_random(length = 8){
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let str = '';
    
    for (let i = 0; i < length; i++) {
        str += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return str;
}