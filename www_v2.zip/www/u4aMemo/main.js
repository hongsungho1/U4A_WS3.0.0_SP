let oAPP = {};
let oUI = {};

document.addEventListener('DOMContentLoaded', async function () { 

    //electron API 오브젝트 
    oAPP = parent.fn_getParent();

    // 키보드 숏컷 이벤트 설정
    fn_onShortCutEvents();

    //UI 생성 
    fn_CreateUI();
    

});

/*================================================================ */
/* [펑션] - UI 생성 
/*================================================================ */
function fn_CreateUI(){

    jQuery.sap.require('sap.ui.codeeditor.CodeEditor');
    oUI.APP = new sap.m.App({autoFocus:false, busyIndicatorDelay:1,height:"100%",width:"100%", busy:true});
    oUI.APP.attachAfterNavigate((e)=>{  oUI.APP.invalidate();  });
    oUI.APP.addStyleClass('sapUiSizeCompact');

    //페이지 생성
    oUI.PAGE = new sap.m.Page({showHeader:true, busyIndicatorDelay:1});
    oUI.APP.addPage(oUI.PAGE);


    //해더 영역 
    var oBarMain  = new sap.m.Bar();

    //저장
    oBarMain.addContentLeft(new sap.m.Button({icon:"sap-icon://save", type:"Emphasized", text:"저장", press:()=>{

    }}));

    oUI.PAGE.setCustomHeader(oBarMain);


    //Editor
    jQuery.sap.require('sap.ui.richtexteditor.RichTextEditor');
   
    oUI.RICHTEXTEDITOR1 = new sap.ui.richtexteditor.RichTextEditor({
        busyIndicatorDelay:1,
        editorType:"TinyMCE6",
        width:"100%",
        height:"100%",
        sanitizeValue:false,
        showGroupClipboard:true,
        showGroupStructure:true,
        showGroupFont:true,
        showGroupInsert:true,
        showGroupLink:true,
        showGroupUndo:true,
        change:function(e){  },
        ready:(e)=>{
            console.log("ready");
            var oInter = setInterval(() => {
                var dom = oUI.RICHTEXTEDITOR1.getDomRef();
                if(!dom){return;}
                if(!dom.querySelector("iframe")){return;}
                if(!dom.querySelector("iframe").contentWindow){return;}
                clearInterval(oInter);

                fn_onEditorEvents(dom.querySelector("iframe").contentWindow);

                //저장 모니터 가동
                fn_saveMonitor(dom.querySelector("iframe").contentWindow);

                return;

            }, 200);

            if(oUI.RICHTEXTEDITOR1.getValue() === ""){
                oUI.RICHTEXTEDITOR1.setValue('<p>&nbsp;</p>\n');
            }

        },
        beforeEditorInit:function (oEvent) {

        }
    });

    oUI.PAGE.addContent(oUI.RICHTEXTEDITOR1);


    //Update UI( DOM 생성이후) 이벤트 핸들러 설정
    sap.ui.getCore().attachEvent(sap.ui.core.Core.M_EVENTS.UIUpdated, fn_UIUPdated);


    /*  최종 Dom 생성  */
    oUI.APP.placeAt("content","only");

}


/*================================================================ */
/* [펑션] - Update UI Callback 
/*================================================================ */
function fn_UIUPdated(){

    //Update UI 이벤트 핸들러 제거 
    sap.ui.getCore().detachEvent(sap.ui.core.Core.M_EVENTS.UIUpdated, fn_UIUPdated);

    //화면 활성 
    $( '#content' ).fadeIn(1500);

    //로딩바 제거 
    oUI.APP.setBusy(false);


    //Find page 팝업 수행 
    oAPP.findInPage = new oAPP.FindInPage.FindInPage(oAPP.remote.getCurrentWebContents(), { 
        duration: 700, 
        preload: true,
        boxBgColor: '#333',
        boxShadowColor: '#000',
        inputColor: '#aaa',
        inputBgColor: '#222',
        inputFocusColor: '#555',
        textColor: '#aaa',
        textHoverBgColor: '#555',
        caseSelectedColor: '#555',
        offsetRight: 30
    });

    oAPP.findInPage.openFindWindow();



}


/*================================================================ */
/* [펑션] - 키보드 숏컷 이벤트 핸들러 설정 
/*================================================================ */
async function fn_onShortCutEvents(funcKey = "alt+q"){

    oAPP.globalShortcut.unregisterAll();
    oAPP.globalShortcut.register(funcKey, ()=>{ 

        if(oAPP.WIN.getOpacity() == 1){
            oAPP.WIN.setOpacity(0);

        }else{
            oAPP.WIN.setOpacity(1);
            oAPP.WIN.setAlwaysOnTop(true);
        }

    });

}

/*================================================================ */
/* [펑션] - 메시지 처리
/*================================================================ */
function fn_message(S, M, CB){

    jQuery.sap.require('sap.m.MessageBox');

    var Licon;
    var T_action = [];

    switch (S) {
        case "S":
            Licon    = sap.m.MessageBox.Icon.SUCCESS;
            T_action = [sap.m.MessageBox.Action.OK];
            break;

        case "E":
            Licon    = sap.m.MessageBox.Icon.ERROR;
            T_action = [sap.m.MessageBox.Action.OK];
            break;

        case "W":
            Licon    = sap.m.MessageBox.Icon.WARNING;
            T_action = [sap.m.MessageBox.Action.OK];
            break;
    
        case "I":
            Licon    = sap.m.MessageBox.Icon.INFORMATION;
            T_action = [sap.m.MessageBox.Action.OK];
            break;

        case "Q":
            Licon    = sap.m.MessageBox.Icon.QUESTION;
            T_action = [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO];
            break;

        default:
            return;
            
    }

    sap.m.MessageBox.show(M, { title:"Confirm", icon: Licon, actions:T_action,onClose:(e)=>{ CB(e); }  });

}


/*================================================================ */
/* [펑션] - 랜덤키 생성
/*================================================================ */
function fn_random(length = 8){
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let str = '';
    
    for (let i = 0; i < length; i++) {
        str += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return str;
}

/*================================================================ */
/* [펑션] - Editor 영역 예외 이벤트 설정
/*================================================================ */
function fn_onEditorEvents(WIN){

    //Editor 영역 이벤트 설정 - contextmenu 
    fn_onEditorContextMenu(WIN);
  
    //Editor 영역 이벤트 설정 - 컨트롤 + 마우스 확대/축소   
    fn_onEditorMousewheel(WIN);

}


/*================================================================ */
/* [펑션] - Editor 영역 이벤트 설정 - contextmenu 
/*================================================================ */
function fn_onEditorContextMenu(WIN){

    WIN.addEventListener("contextmenu", (e)=>{ 
        e.stopPropagation();
        e.preventDefault();


        var T_MENU = [
            {label: '(활성/비활성) 키보드 단축키 설정', icon:oAPP.path.join(oAPP.__dirname, "img", "keyboard_36110.png"), click (){ fn_menu01(); }}

            ];
      
        var oMenu = oAPP.Menu.buildFromTemplate(T_MENU);
            oMenu.popup();


    });

}


/*================================================================ */
/* [펑션] - contextmenu  (활성/비활성) 키보드 단축키 설정
/*================================================================ */
function fn_menu01(){

    var oDialog = new sap.m.Dialog({showHeader:false, contentWidth:"600px"});
        oDialog.attachAfterClose((e)=>{
            oDialog.destroy();

        });

    var oInput  = new sap.m.Input({placeholder:"예제) alt+q esc f1~f10 기타 등등 단축키"});

    oDialog.addContent(oInput);

    oDialog.addButton(new sap.m.Button({text:"설정", type:"Emphasized", press:()=>{

        oInput.setValueState("None");
        if(oInput.getValue() === ""){
            oInput.setValueState("Error");
            return;

        }
        
        //숏컷 설정
        fn_onShortCutEvents(oInput.getValue());
        sap.m.MessageToast.show("등록 완료");
        oDialog.close();

    }}));

    oDialog.addButton(new sap.m.Button({text:"종료", type:"Reject", press:()=>{
        oDialog.close();

    }}));




    oDialog.open();


}


/*================================================================ */
/* [펑션] - 저장 모니터 가동 
/*================================================================ */
function fn_saveMonitor(WIN){


    //Dom 변화 감지 
    var observer = new MutationObserver(lfn_TimerReset);
    observer.observe(WIN.document.body, {attributes: true, childList: true, characterData: true });

    //keyup 
    WIN.document.addEventListener("keyup", lfn_TimerReset);

    //Data변경
    oUI.RICHTEXTEDITOR1.attachChange(lfn_TimerReset);


    function lfn_TimerReset(e){

        console.log("값 변경 타이머 초기화 해야함");

    }






}


/*================================================================ */
/* [펑션] - Editor 영역 이벤트 설정 - 컨트롤 + 마우스 확대/축소 
/*================================================================ */
function fn_onEditorMousewheel(WIN){

    //마우스 휠 ZOOM 이벤트 설정
    oAPP._scale = oAPP.WEBCONTENT.getZoomLevel(); 

    WIN.addEventListener('mousewheel', (ev) => {

        if (ev.ctrlKey) {
        
            oAPP._scale += ev.deltaY * -0.01;
            oAPP._scale = Math.min(Math.max(-10, oAPP._scale), 10);
            //var oDOM = oUI.RICHTEXTEDITOR1.getDomRef();
            //oDOM.style.zoom = oAPP._scale;
            oAPP.WEBCONTENT.setZoomLevel(oAPP._scale);
        
        }

    });

}