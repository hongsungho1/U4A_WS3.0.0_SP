let oWEBVIEW = document.createElement("webview");
oWEBVIEW.setAttribute("id", "mainFRAME");
oWEBVIEW.setAttribute("src", "https://papago.naver.com/");
oWEBVIEW.setAttribute("preload", "preload.js");
oWEBVIEW.setAttribute("partition", gn_random());
oWEBVIEW.setAttribute("sandbox", "false");
oWEBVIEW.setAttribute("enableremotemodule", "true");
oWEBVIEW.setAttribute("guestinstance", "3");

oWEBVIEW.addEventListener('dom-ready', async () => {

    oWEBVIEW.nodeintegration = true;       //require와 process 객체같은 node.js API를
    //oWEBVIEW.plugins = true;             // webview 내부에서 브라우저 플러그인을 사용할 수 있습니다.
    oWEBVIEW.disablewebsecurity = true;    //페이지의 웹 보안을 해제합니다.
    //oWEBVIEW.guestinstance = 1;
    //oWEBVIEW.sandbox = false;
    oWEBVIEW.contextIsolation = false;

    oWEBVIEW.nativeWindowOpen = true;

    //Webview 콘솔창 실행 
    if(!oAPP.remote.app.isPackaged){
        oWEBVIEW.openDevTools();           

    }


    //키보드 숏컷 이벤트 설정 
    gn_onGlobalShortcut();
    

});


/*===================================================================*/
// WEBVIEW 영역에서 호출했을경우 아래 이벤트에 callback 됨!!
/*===================================================================*/

/*
oWEBVIEW.addEventListener('ipc-message', async (e) => {

    switch (e.channel) {
        case "U4A_AREA_ERROR": //오류 
            break;

        case "U4A_AREA_ERROR": //오류
            break; 

        default:
            break;
    }

});
*/


document.body.append(oWEBVIEW);


/*===================================================================*/
// 내부 사용 펑션 선언 
/*===================================================================*/

//번역 실행
async function gn_run(){
    
    oAPP.T_DATA = [];

    //번역 정보 List Data 추출 
    if(oAPP.T_DATA.length === 0){

        //oAPP.T_DATA.push({DESCR:"Fired after a new value for a bound property has been propagated to the model. Only fired, when the binding uses a ", LIBNM:"sap.ui.base.ManagedObject", UIATT:"validationSuccess", UIATY:"2"});
        //oAPP.T_DATA.push({DESCR:"Defines a custom tooltip for the badgeIcon. If set, it overrides the available default values If not set,", LIBNM:"sap.ui.base.ManagedObject", UIATT:"validationSuccess", UIATY:"2"});
        //oAPP.T_DATA.push({DESCR:"initial settings for the new control", LIBNM:"sap.ui.base.ManagedObject", UIATT:"validationSuccess", UIATY:"2"});
                        
        /*
        oAPP.T_DATA.push({UIATK:"AAAAAA", FROM_TXT:"HELLO", TO_TXT:""});
        oAPP.T_DATA.push({UIATK:"AAAAAA", FROM_TXT:"id for the new control, generated automatically if no id is given", TO_TXT:""});
        oAPP.T_DATA.push({UIATK:"AAAAAA", FROM_TXT:"initial settings for the new control", TO_TXT:""});
        oAPP.T_DATA.push({UIATK:"AAAAAA", FROM_TXT:"Defines a custom tooltip for the badgeIcon. If set, it overrides the available default values If not set, default tooltips are used as follows:", TO_TXT:""});
        oAPP.T_DATA.push({UIATK:"AAAAAA", FROM_TXT:"Specifies custom display size of the Avatar Note: It takes effect if the displaySize property is set to Custom.", TO_TXT:""});
        */
    }

    oAPP.IS_STOP = false;

    async function lfn_ipc(e){
        
        switch (e.channel) {
            case "get_edit_postion": //번역 from editor dom 포지션 얻기
                
                oAPP.transInfo.x = e.args[0].x;
                oAPP.transInfo.y = e.args[0].y;
                
                //자동 반복 실행
                lfn_autoRun();

                break;
    
            case "get_translation_value": //오류
              
                oAPP.T_TRANS.push(e.args[0]);

                //기다려
                await gfn_waite(1000);

                await oAPP.f_KeyBordHandle("ctrl+a", 200);
                await oAPP.f_KeyBordHandle("backspace", 200); 

                //기다려
                await gfn_waite(3000);

                //자동 반복 실행
                lfn_autoRun();

                break; 
    
            default:
                break;
        }

    }

    oWEBVIEW.addEventListener('ipc-message', lfn_ipc);


    //자동 반복 실행
    async function lfn_autoRun(){

        if(oAPP.IS_STOP){ oWEBVIEW.removeEventListener('ipc-message', lfn_ipc); return; }

        if(oAPP.T_DATA.length === 0){ 

            oWEBVIEW.removeEventListener('ipc-message', lfn_ipc);
            oAPP.IS_STOP = true;

            //저장 
            await gfn_SAVE();

            return;

        }
     

        var S_DATA = oAPP.T_DATA[0];
        oAPP.T_DATA.shift();


        //스크롤 최상위 이동
        var LV_JS   = '(function(){'
                    + 'window.scrollTo(0, 0);'
                    + '})();';

        await oWEBVIEW.executeJavaScript(LV_JS , true);  

        //기다려
        await gfn_waite(300);


        //번역 대상 TEXT 특수문자 제거 및 문자 길이 제한 
        var LV_DESCR = gfn_SUBSTR(S_DATA.DESCR); 
            LV_DESCR = gfn_escapeRegex(LV_DESCR); 
             
            
        //번역 대상 text 전송
        var LV_JS   = '(function(){'
                    + 'try {'
                    + 'document.getElementById("txtSource").value = "' +  LV_DESCR + '";'
                    + '} catch (e) {}'
                    + '})();';

        await oWEBVIEW.executeJavaScript(LV_JS , true);  

        //기다려
        await gfn_waite(500);

        //텍스트 위치 좌표 이동
        oAPP.node_screen.mousemove({
            x: oAPP.transInfo.x + 50,
            y: oAPP.transInfo.y + 200
        }, async function() {

            oAPP.node_screen.mouseclick('left');
            await oAPP.f_KeyBordHandle("enter", 500);

            //기다려
            await gfn_waite(500);


            //번역 대상 TEXT 특수문자 제거 및 문자 길이 제한 
            var LV_DESCR = gfn_SUBSTR(S_DATA.DESCR); 
                LV_DESCR = gfn_escapeRegex(LV_DESCR); 
    
            //번역 정보 얻기
            var LV_JS   = '(function(){'
                        + 'var oLANG = document.getElementById("ddTargetLanguage2Button");'
                        + 'var LANG  = oLANG.innerHTML.replace(/<[^>]*>?/g, "");'
                        + 'var oInterv = setInterval(() => {'
                        + 'var oDOM = document.getElementById("txtTarget");'
                        + 'if(oDOM.innerText === ""){ return; }'
                        + 'if(oDOM.innerText === "."){ return; }'
                        + 'if(oDOM.innerText === ".."){ return; }'
                        + 'if(oDOM.innerText === "..."){ return; }'
                        + 'if(oDOM.innerText === "...."){ return; }'
                        + 'window.U4A.send("get_translation_value", { UIATY:"' + S_DATA.UIATY + '", LIBNM:"' + S_DATA.LIBNM + '", UIATT:"' + S_DATA.UIATT + '", FROM_DESCR:"' + LV_DESCR + '", TO_DESCR: oDOM.innerText, LANGU:LANG });'
                        + 'clearInterval(oInterv);'
                        + '}, 2000);'
                        + '})();';

            await oWEBVIEW.executeJavaScript(LV_JS , true);
            

           
        });


    } //async function lfn_autoRun(){


    //번역 from editor 영역 dom 포지션 이전 수집정보가 존재한다면 ..  
    if(typeof oAPP.transInfo.x !== "undefined" ){
        //자동 반복 실행
        lfn_autoRun();
        return;
    }


    //번역 from editor 영역 dom 포지션 정보 얻기    
    var LV_JS   = '(function(){'
                + 'var sRect = document.getElementById("txtSource").getBoundingClientRect();'
                + 'window.U4A.send("get_edit_postion", {x:sRect.x, y:sRect.y});'
                + '})();';

    await oWEBVIEW.executeJavaScript(LV_JS , true);   


}


//번역 실행
async function gn_stop(){

    oAPP.IS_STOP = true;

    return;

    const options = {
        type: 'question',  //종류
        title: '중지',     //제목
        message: '중지',
        detail: '중지'
    };
    
    oAPP.remote.dialog.showMessageBox(null, options).then(function(res){ });

}


//키보드 숏컷 이벤트 설정
function gn_onGlobalShortcut(){
    

    //실행 
    oAPP.globalShortcut.register('f8', ()=>{ gn_run();  });

    //중지
    oAPP.globalShortcut.register('esc', ()=>{ gn_stop();  });


    //콘솔창 실행
    oAPP.globalShortcut.register('f1', ()=>{ 
      
        oAPP.WIN.openDevTools();
        oWEBVIEW.openDevTools();  

    });

}


//랜덤키
function gn_random(length = 15){

    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let str = '';

    for (let i = 0; i < length; i++) {
    str += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    return str;

}


//기다려
async function gfn_waite(TIME){
    return new Promise((res, rej)=>{
        setTimeout(() => { res("END"); }, TIME);
            
    });
}

//문자열 특수문자 제거 
function gfn_escapeRegex(string) {

    var LV_VAL = string.replaceAll('\n', '');
        LV_VAL = LV_VAL.replaceAll('"', '');

    return LV_VAL;
}


//문자 길이 제한
function gfn_SUBSTR(string) {
    return string.substr(0, 3000);
}


function gnf_convLangu(LANG){

    switch (LANG) {
        case "한국어":
            return "KO";
            break;
    
        default:
            return "EN";
            break;

    }

}


//저장 
async function gfn_SAVE() {
    return new Promise((resolve, reject) => {

        //저장 처리 완료 정보가 없다면 
        if(oAPP.T_TRANS.length == 0){

            //완료 메시지  
            var options = {
                type: 'question',  //종류
                title: '완료',     //제목
                message: '처리 정보가 없습니다',
                detail: '완료'
            };
            
            oAPP.remote.dialog.showMessageBox(null, options).then(function(res){ oWEBVIEW.closeDevTools(); oAPP.WIN.close(); });

            resolve(1);

        }


        var LV_SAVE_PATH = process.env.TMP || process.env.TEMP;
       
        //저장 폴더 생성
        LV_SAVE_PATH = oAPP.path.join(LV_SAVE_PATH,"WS30");
        if(!oAPP.fs.existsSync(LV_SAVE_PATH)){
            oAPP.fs.mkdirSync(LV_SAVE_PATH);  
        }

        LV_SAVE_PATH = oAPP.path.join(LV_SAVE_PATH,"TRANSLATION");
        if(!oAPP.fs.existsSync(LV_SAVE_PATH)){
            oAPP.fs.mkdirSync(LV_SAVE_PATH);  
        }        


        //오늘 날짜 + 시분초 폴더 생성
        let today = new Date();
        let year  = today.getFullYear().toString();  // 년도
        let month = today.getMonth() + 1; // 월
            month = month.toString();
            month = month.padStart(2, '0');
        let date = today.getDate().toString(); // 날짜
            date = date.padStart(2, '0');      // 0자붙이기

        //시분초
        let Hours    = today.getHours().toString();
        let Minutes  = today.getMinutes().toString();
        let Seconds  = today.getSeconds().toString();

        var LV_TIMESTMP = year + month + date + "_" + Hours + Minutes + Seconds;
        LV_SAVE_PATH = oAPP.path.join(LV_SAVE_PATH, LV_TIMESTMP);
        if(!oAPP.fs.existsSync(LV_SAVE_PATH)){
            oAPP.fs.mkdirSync(LV_SAVE_PATH);  
        }      


        //최초 I/F 전송 구조 
        //[{DESCR:"내역", LIBNM:"sap.ui.base.ManagedObject", UIATT:"validationSuccess", UIATY:"2"}]

        //자동 번역 처리후 수집된 구조 
        //[{"UIATY":"2","LIBNM":"sap.ui.base.ManagedObject","UIATT":"validationSuccess","FROM_DESCR":"번역전 TXT","TO_DESCR":"번역 TXT","LANGU":"한국어"}]
        
        
        //번역 언어정보 얻기
        var LV_LANGU = gnf_convLangu(oAPP.T_TRANS[0].LANGU);

        //언어 폴더 생성
        LV_SAVE_PATH = oAPP.path.join(LV_SAVE_PATH, LV_LANGU);
        if(!oAPP.fs.existsSync(LV_SAVE_PATH)){
            oAPP.fs.mkdirSync(LV_SAVE_PATH);  
        }             
        

        //저장 Data 구성 
        var LT_SAVE = [];
        for (let i = 0; i < oAPP.T_TRANS.length; i++) {
            var S_TRANS = oAPP.T_TRANS[i];

            var LS_SAVE = {};
                LS_SAVE.UIATY = S_TRANS.UIATY;
                LS_SAVE.LIBNM = S_TRANS.LIBNM;
                LS_SAVE.UIATT = S_TRANS.UIATT;
                LS_SAVE.LANGU = LV_LANGU;
                LS_SAVE.DESCR = S_TRANS.TO_DESCR;

                LT_SAVE.push(LS_SAVE);

        }

        oAPP.T_TRANS = [];
        oAPP.T_DATA  = [];


        LV_SAVE_PATH = oAPP.path.join(LV_SAVE_PATH,"UI5_UI_DESCR.json");
        oAPP.fs.writeFileSync(LV_SAVE_PATH, JSON.stringify(LT_SAVE), 'utf-8');
        

        //완료 메시지  
        var options = {
            type: 'question',  //종류
            title: '완료',     //제목
            message: '완료',
            detail: '완료'
        };
        
        oAPP.remote.dialog.showMessageBox(null, options).then(function(res){  
            oAPP.remote.shell.showItemInFolder(LV_SAVE_PATH);
            oWEBVIEW.closeDevTools();
            oAPP.WIN.close(); 

        });

        resolve(1);


    });
}
