// I/F 필드 정의 
/* ***************************************************************** */
/*
*/
/* ***************************************************************** */
/* ***************************************************************** */
/* 사용 예시 
    var getDesc = require(oAPP.path.join(__dirname, 'AutoTranslationPapago/getLibraryDesc/index.js'));
    var retdata = await getDesc.getLibDesc(oAPP);
    retdata.RETCD <-- E:오류, S:성공
    retdata.RTMSG <-- 처리 메시지.
    retdata.T_DESC <-- UI ATTRIBUTE의 DESC 정보.
        ([{LIBNM:"sap.m.Input", UIATY:"1", UIATT:"maxLength", UIADT:"int", DEFVL:0, DESCR:"설명"},
          {LIBNM:"sap.m.Input", UIATY:"2", UIATT:"submit", DESCR:"설명"},
          {LIBNM:"sap.m.Input", UIATY:"3", UIATT:"suggestionItems", UIADT:"sap.ui.core.Item", CARDI:"0..n", DESCR:"설명"},
          {LIBNM:"sap.m.Input", UIATY:"4", UIATT:"selectedRow", UIADT:"sap.m.ColumnListItem", CARDI:"0..1", DESCR:"설명"}
        ])
      
*/
/* ***************************************************************** */
/* ***************************************************************** */
/* 내부 광역 변수  
/* ***************************************************************** */

//폴더 선택 팝업 default 경로.
const C_DEFAULT_PATH = "D:\\";

//폴더 선택 팝업 타이틀.
const C_FILE_BROWSER_TITLE = "Choose library folder";

//electron 정보.
let oAPP;

//라이브러리 수집 array(sap.m)
let lt_lib = [];

//라이브러리\\designtime\\api.json 경로로 부터 api.json 파일 read 실패 수집 array
let lt_fail = [];

//클래스 수집 array(sap.m.Button)
let lt_class = [];

//클래스의 desc 수집 array(return 처리용)
let lt_desc = [];


/* ***************************************************************** */
/* 내부 전역 펑션 
/* ***************************************************************** */

//광역변수 초기화.
function lf_clearGlovalVal(){
    lt_lib = [], lt_fail = [], lt_desc = [], lt_class = [], oAPP = null;

}   //광역변수 초기화.



//라이브러리 json 파일 정보 얻기.
function lf_getJsonFile(sPath, resolve){
    
    if(!sPath || sPath === ""){
        resolve({"RETCD":"E", "RTMSG":"폴더 선택을 취소함"});

        //광역변수 초기화.
        lf_clearGlovalVal();
        return;
    }
    
    //api-index.json path 구성.
    try{
        var l_path = oAPP.path.join(sPath, "docs", "api", "api-index.json");
    }catch(e){
    }    

    if(!l_path || l_path === ""){
        resolve({"RETCD":"E", "RTMSG":"선택한 폴더 안에 api-index.json 정보가 존재하지 않음."});
        
        //광역변수 초기화.
        lf_clearGlovalVal();
        return;
    }
    

    //api-index.json 정보 얻기.
    try{
        var l_json = JSON.parse(oAPP.fs.readFileSync(l_path, "utf-8"));
    }catch(e){
    }
    
    if(!l_json){
        resolve({"RETCD":"E", "RTMSG":"api-index.json파일 읽기 실패"});

        //광역변수 초기화.
        lf_clearGlovalVal();
        return;
    }

    //라이브러리 정보 수집.
    lf_collectLibData(l_json.symbols[0]);
    
    if(lt_lib.length === 0){
        resolve({"RETCD":"E", "RTMSG":"api-index.json파일 안에서 라이브러리 정보 얻기 실패."});
        
        //광역변수 초기화.
        lf_clearGlovalVal();
        return;
    }
    

    //수집한 라이브러리의 api.json 파일 얻기.
    lf_getLibApiJson(sPath);

    //클래스 수집건이 존재하지 않는경우.
    if(lt_class.length === 0){
        resolve({"RETCD":"E", "RTMSG":"UI 클래스 정보 수집 실패"});
        return;
    }

    //라이브러리 api.json 정보를 얻지 못한건이 존재하는경우.
    if(lt_fail.length !== 0){
        resolve({"RETCD":"E", "RTMSG":lt_fail.join("\n")});

        //광역변수 초기화.
        lf_clearGlovalVal();
        return;
    }

    //라이브러리의 DESC 수집.
    lf_getLibDesc();

    if(lt_desc.length === 0){
        resolve({"RETCD":"E", "RTMSG":"DESC 정보 수집 실패"});
        
        //광역변수 초기화.
        lf_clearGlovalVal();        
        return;
    }


    //성공 FLAG와 수집된 desc 정보 return.
    resolve({"RETCD":"S", "RTMSG":"DESC정보 수집 완료.", T_DESC:lt_desc});

    //광역변수 초기화.
    lf_clearGlovalVal();

}   //라이브러리 json 파일 정보 얻기.



//라이브러리 정보 수집.
function lf_collectLibData(is_lib){

    if(!is_lib){return;}

    //라이브러리가 수집되지 않은건만 수집 처리.
    if(is_lib.kind === "namespace" && lt_lib.findIndex( a => a === is_lib.lib) === -1){
        lt_lib.push(is_lib.lib);
    }

    
    if(!is_lib.nodes || is_lib.nodes.length === 0){return;}

    //하위 정보가 존재하는경우 하위를 탐색하며 라이브러리정보 수집.
    for(var i=0, l=is_lib.nodes.length; i<l; i++){        

        lf_collectLibData(is_lib.nodes[i]);

    }

}  //라이브러리 정보 수집.



//수집한 라이브러리의 클래스 정보 수집.
function lf_getClassData(it_node){

    if(it_node.length === 0){return;}

    for(var i=0, l=it_node.length; i<l; i++){

        //클래스가 아닌건은 skip.
        if(it_node[i].kind !== "class"){continue;}

        //attr 정보가 존재하지 않는경우 skip.
        if(!it_node[i]["ui5-metadata"]){continue;}

        //클래스 정보 수집.
        lt_class.push(it_node[i]);

    }

}   //수집한 라이브러리의 클래스 정보 수집.



//수집한 라이브러리의 api.json 파일 얻기.
function lf_getLibApiJson(sPath){

    if(lt_lib.length === 0){return;}

    //수집한 라이브러리내부에 있는 designtime 폴더의 api.json 파일 read.
    for(var i=0, l=lt_lib.length; i<l; i++){

        //파일 경로를 구성하기 위해 라이브러리 를 path형식으로 변경
        //(sap.ui.table -> sap\\ui\\table)
        var l_lib = lt_lib[i].replaceAll(".", "\\");

        //read 대상 파일 path 구성.
        try{
            var l_path = oAPP.path.join(sPath, "test-resources", l_lib,  "designtime", "api.json");
        }catch(e){
        }
        
        if(!l_path || l_path === ""){
            lt_fail.push(lt_lib[i] + "경로 탐색 실패");
            continue;
        }

        //path에 해당하는 api.json 파일 read.
        try{
            var l_json = JSON.parse(oAPP.fs.readFileSync(l_path, "utf-8"));
        }catch(e){
        }
        
        if(!l_json){
            lt_fail.push(lt_lib[i] + "api.json 얻기 실패");
            continue;
        }
        
        //라이브러리의 클래스 정보 수집.
        lf_getClassData(l_json.symbols);

    }

}   //수집한 라이브러리의 api.json 파일 얻기.



//라이브러리의 DESC 수집.
function lf_getLibDesc(){

    if(lt_class.length === 0){return;}

    for(var i=0, l=lt_class.length; i<l; i++){

        //프로퍼티 description 수집.
        lf_getPropertyDesc(lt_class[i], lt_class[i].name, lt_class[i].basename);

        //이벤트 description 수집.
        lf_getEventDesc(lt_class[i], lt_class[i].name, lt_class[i].basename);

        //Aggregation description 수집.
        lf_getAggregationDesc(lt_class[i], lt_class[i].name, lt_class[i].basename);

        //Association description 수집.
        lf_getAssociationDesc(lt_class[i], lt_class[i].name, lt_class[i].basename);

        // //부모 attr의 desc 정보를 같이 수집.
        // lf_getLibDescParent(lt_class[i], lt_class[i].name, lt_class[i].basename);

    }

}   //라이브러리의 DESC 수집.



//부모 attr의 desc 정보를 같이 수집.
function lf_getLibDescParent(is_class, LIBNM, UIOBJ){

    var l_parent = lt_class.find( a =>  a.name === is_class.extends );
    if(!l_parent){return;}

    //부모의 프로퍼티 description을 자신UI에 수집.
    lf_getPropertyDesc(l_parent, LIBNM, UIOBJ);

    //부모의 이벤트 description을 자신UI에 수집.
    lf_getEventDesc(l_parent, LIBNM, UIOBJ);

    //부모의 Aggregation description을 자신UI에 수집.
    lf_getAggregationDesc(l_parent, LIBNM, UIOBJ);

    //부모의 Association description을 자신UI에 수집.
    lf_getAssociationDesc(l_parent, LIBNM, UIOBJ);

    //부모의 상위를 계속 탐색하며 attr 정보 수집.
    lf_getLibDescParent(l_parent, LIBNM, UIOBJ);


}   //부모 attr의 desc 정보를 같이 수집.



//프로퍼티 description 수집.
function lf_getPropertyDesc(is_node, LIBNM, UIOBJ){

    //프로퍼티 정보가 없다면 exit.
    if(!is_node["ui5-metadata"]?.properties?.length){return;}

    for(var i=0, l=is_node["ui5-metadata"].properties.length; i<l; i++){

        //public인 프로퍼티만 수집.
        if(is_node["ui5-metadata"].properties[i].visibility !== "public"){continue;}

        //desc정보가 존재하지 않는경우 skip.
        if(!is_node["ui5-metadata"].properties[i].description){continue;}
        
        lt_desc.push({
            LIBNM:LIBNM,
            // UIOBJ:UIOBJ,
            UIATY:"1",
            UIATT:is_node["ui5-metadata"].properties[i].name,
            UIADT:is_node["ui5-metadata"].properties[i].type,
            DEFVL:is_node["ui5-metadata"].properties[i].defaultValue,
            DESCR:is_node["ui5-metadata"].properties[i].description.replace(/<[^>]*>?/g, "")
        });
    }

}   //프로퍼티 description 수집.



//이벤트 description 수집.
function lf_getEventDesc(is_node, LIBNM, UIOBJ){

    //이벤트 정보가 없다면 exit.
    if(!is_node["ui5-metadata"]?.events?.length){return;}

    for(var i=0, l=is_node["ui5-metadata"].events.length; i<l; i++){

        //public인 이벤트만 수집.
        if(is_node["ui5-metadata"].events[i].visibility !== "public"){continue;}

        //desc정보가 존재하지 않는경우 skip.
        if(!is_node["ui5-metadata"].events[i].description){continue;}
        
        lt_desc.push({
            LIBNM:LIBNM,
            // UIOBJ:UIOBJ,
            UIATY:"2",
            UIATT:is_node["ui5-metadata"].events[i].name,
            DESCR:is_node["ui5-metadata"].events[i].description.replace(/<[^>]*>?/g, "")
        });
    }

}   //이벤트 description 수집.



//Aggregation description 수집.
function lf_getAggregationDesc(is_node, LIBNM, UIOBJ){

    //Aggregation정보가 없다면 exit.
    if(!is_node["ui5-metadata"]?.aggregations?.length){return;}

    for(var i=0, l=is_node["ui5-metadata"].aggregations.length; i<l; i++){

        //public인 Aggregation만 수집.
        if(is_node["ui5-metadata"].aggregations[i].visibility !== "public"){continue;}

        //desc정보가 존재하지 않는경우 skip.
        if(!is_node["ui5-metadata"].aggregations[i].description){continue;}
        
        lt_desc.push({
            LIBNM:LIBNM,
            // UIOBJ:UIOBJ,
            UIATY:"3",
            UIATT:is_node["ui5-metadata"].aggregations[i].name,
            UIADT:is_node["ui5-metadata"].aggregations[i].type,
            CARDI:is_node["ui5-metadata"].aggregations[i].cardinality,
            DESCR:is_node["ui5-metadata"].aggregations[i].description.replace(/<[^>]*>?/g, "")
        });
    }

}   //Aggregation description 수집.



//Association description 수집.
function lf_getAssociationDesc(is_node, LIBNM, UIOBJ){

    //Association정보가 없다면 exit.
    if(!is_node["ui5-metadata"]?.associations?.length){return;}

    for(var i=0, l=is_node["ui5-metadata"].associations.length; i<l; i++){

        //public인 Association만 수집.
        if(is_node["ui5-metadata"].associations[i].visibility !== "public"){continue;}

        //desc정보가 존재하지 않는경우 skip.
        if(!is_node["ui5-metadata"].associations[i].description){continue;}
        
        lt_desc.push({
            LIBNM:LIBNM,
            // UIOBJ:UIOBJ,
            UIATY:"4",
            UIATT:is_node["ui5-metadata"].associations[i].name,
            UIADT:is_node["ui5-metadata"].associations[i].type,
            CARDI:is_node["ui5-metadata"].associations[i].cardinality,
            DESCR:is_node["ui5-metadata"].associations[i].description.replace(/<[^>]*>?/g, "")
        });
    }

}   //Association description 수집.



/* ================================================================= */
/* Export Module Function 
/* ================================================================= */
exports.getLibDesc = async function(OAPP){
    return new Promise((resolve, reject) => {

        //광역변수 초기화.
        lf_clearGlovalVal();

        //electron 정보 광역화.
        oAPP = OAPP;

        var options = {
            title : C_FILE_BROWSER_TITLE,
            defaultPath : C_DEFAULT_PATH,
            properties: ["openDirectory"]
        };

        //폴더 선택 팝업 호출.
        oAPP.remote.dialog.showOpenDialog(oAPP.remote.getCurrentWindow(), options).then((e)=>{ 
            lf_getJsonFile(e.filePaths[0], resolve);
 
        });

    });

};

