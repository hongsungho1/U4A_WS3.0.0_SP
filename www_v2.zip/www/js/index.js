let oUI5 = {};

const oAPP = {
    onStart:function(){
        this.remote = require('@electron/remote');
	    this.remote.nativeTheme.themeSource = "dark";
        this.ipcMain = this.remote.require('electron').ipcMain;
        this.ipcRenderer = require('electron').ipcRenderer;
        this.fs = this.remote.require('fs');
        this.path = this.remote.require('path');
        this.__dirname = __dirname;
		this.globalShortcut = oAPP.remote.require('electron').globalShortcut;


		oAPP.onSP_UPGRADE();
		//this.onCompress_JS();

		oAPP.fn = {};

		oAPP.fn.getScript = function(fname, callbackFunc, bSync){
			var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					debugger;
				  eval(this.responseText);
				  //new Function(this.responseText);
				  callbackFunc();
				}else{
		  
				}
			  };
		
			  var l_async = true;
			  if(bSync === true){
				l_async = false;
			  }
		
			  xhttp.open("GET", fname + ".js", l_async);
			  xhttp.send();
		
		  };  //js 파일 load

        
    
    },

	onSmartOfficeGETPDF: ()=>{
		
		(function(DBKEY, STRCODE){
			debugger;
			var SEND_DATA = JSON.stringify({"body":{ "dbKey":DBKEY, "strCode":STRCODE }});
			//var SEND_DATA = JSON.stringify({"body":{ "dbKey":"3832774", "strCode":"1026" }});
			//var SEND_DATA = JSON.stringify({"body":{ "dbKey":"99392393", "strCode":"1111" }});
			var xhttp = new XMLHttpRequest();

			xhttp.onload = (e)=>{
				debugger;

				try {
					var sDATA = JSON.parse(e.target.response); 
				} catch (err) {
					//통신 오류!!!
					return;
			
				}
			
				//통신 오류
				if(typeof sDATA.head?.result_code === "undefined"){
				//통신 오류!!!
				return;
			
				}

				if(sDATA.head.result_code !== "200"){
					alert(sDATA.head.result_code);
					return;
				}

				alert(sDATA.body.data);

				return;

				//스마트 (M) 뷰어 호출
				var IF_DATA = {
					type: "binary",
					param : sDATA.body.data.replace(/\r\n/gi, "")
					};

				var callback = M.response.on(function(result){}).toString();

				M.execute("callPdfView", IF_DATA, callback);

			};

			xhttp.onerror = (e)=>{ debugger; };
			xhttp.ontimeout = ()=>{ debugger;};
			xhttp.open("post", "https://smo.emart.com/api/pog/selectPOGPdf", true); 
			xhttp.setRequestHeader("Content-Type", "application/json");
			xhttp.withCredentials = true;
			xhttp.send(SEND_DATA);

		})("3832774", "1026" );

	},

/* =========================================================================== */    
// 웹뷰 생성
/* =========================================================================== */ 
	onCrtWebview: async ()=>{

		
		//UI5 API 설명 정보 추출
		var getDesc = require(oAPP.path.join(__dirname, 'AutoTranslationPapago/getLibraryDesc/index.js'));
		var retdata = await getDesc.getLibDesc(oAPP);

	

		var LT_SAVE = [];
        for (let i = 0; i < retdata.T_DESC.length; i++) {
            var S_TRANS = retdata.T_DESC[i];

            var LS_SAVE = {};
                LS_SAVE.UIATY = S_TRANS.UIATY;
                LS_SAVE.LIBNM = S_TRANS.LIBNM;
                LS_SAVE.UIATT = S_TRANS.UIATT;
                LS_SAVE.LANGU = "EN";
                LS_SAVE.DESCR = S_TRANS.DESCR;

                LT_SAVE.push(LS_SAVE);

        }


		LV_SAVE_PATH = oAPP.path.join(__dirname, "data", "desc", "EN", "UI5_UI_DESCR.json");
		oAPP.fs.writeFileSync(LV_SAVE_PATH, JSON.stringify(LT_SAVE), 'utf-8');

		return;


		if(retdata.RETCD === "E"){

			//완료 메시지  
			var options = {
				type: 'question',  //종류
				title: '처리 오류',     //제목
				message: retdata.RTMSG,
				detail: retdata.RTMSG
			};
			
			oAPP.remote.dialog.showMessageBox(null, options).then(function(res){  });
			return;
		}


		var op = {
			"height": screen.availHeight,
			"width": screen.availWidth,
			"modal":false,
			"alwaysOnTop":false,
			"fullscreen":false,
			"parent": oAPP.remote.getCurrentWindow(),
			"webPreferences":{
				"devTools": true,
				"nodeIntegration":true,
				"enableRemoteModule":true,
				"contextIsolation": false,
				"nativeWindowOpen": true,
				"webSecurity": false,
				"webviewTag":true

			}
			
		};

		oAPP.remote.getCurrentWindow().closeDevTools();

		delete oAPP._WIN;
		oAPP._WIN = new oAPP.remote.BrowserWindow(op);
		oAPP._WIN.setMenu(null);


		oAPP._WIN.loadURL(`file://${__dirname}/AutoTranslationPapago/index.html`);

		oAPP._WIN.webContents.on('did-finish-load', ()=> {
			
			if(!oAPP.remote.app.isPackaged){
				oAPP._WIN.openDevTools(); 
			}
			
			//번역 대상 정보 전송
			oAPP._WIN.webContents.send('IF-AUTO-TRAMSLATE-PAPAGO', { TARGET: retdata.T_DESC });

			oAPP._WIN.focus();


		});


		oAPP._WIN.on('close', ()=>{
			oAPP.globalShortcut.unregisterAll();
			oAPP.remote.getCurrentWindow().focus();

		});
		

		var remote = require('@electron/remote');
		remote.require('@electron/remote/main').enable(oAPP._WIN.webContents);   

	},

/* =========================================================================== */    
// U4A 메모 실행
/* =========================================================================== */   	
	onMemoOpen: ()=>{

		var op = {
			"height": screen.availHeight,
			"width": screen.availWidth,
			"modal": false,
			"show": false,
			"minHeight":280,
			"minWidth":300,
			"resizable": true,
			"skipTaskbar": true,
			"icon": oAPP.path.join(oAPP.__dirname, 'img/logo.png'),
			"title":"U4A MEMO",
			"autoHideMenuBar": true,
			//"transparent": true, 
			//"frame": false,
			//"partition": lfn_random(70), 
			"parent": oAPP.remote.getCurrentWindow(), 
			"webPreferences":{
				"devTools": true,
				"nodeIntegration": true,
				"contextIsolation": false,
				"nativeWindowOpen": true,
				"webSecurity": false,
				"sandbox": false
			}
		   
		};

		oAPP.remote.getCurrentWindow().webContents.closeDevTools();
		oUI5._win10 = new oAPP.remote.BrowserWindow(op);
		oUI5._win10  = new oAPP.remote.BrowserWindow(op);
		oUI5._win10 .setMenu(null);

		oUI5._win10.loadURL(`file://${oAPP.__dirname}/u4aMemo/index.html`); 
		oAPP.remote.require('@electron/remote/main').enable(oUI5._win10.webContents);
		
		oUI5._win10.on('close', function(e){
            delete oUI5._win10;
			//oAPP.remote.getCurrentWindow().close();
			oAPP.remote.getCurrentWindow().focus();
		
    	});

		oUI5._win10.webContents.on('did-finish-load', ()=> {
			//oUI5._win10.setFullScreen(true);
			oUI5._win10.show();

			if(!oAPP.remote.app.isPackaged){
				oUI5._win10.webContents.openDevTools();
			}
			
		});



	},
    
/* =========================================================================== */    
// js 파일 수정후 압축 화면 호출
/* =========================================================================== */       
    onCompress_JS : ()=>{

        if(typeof oUI5._win09 !== "undefined"){ return; }


		var op = {
			"height": 800,
			"width": 1000,
			"modal": false,
			"show": false,
			"minHeight":280,
			"minWidth":700,
			"resizable": true,
			"skipTaskbar": true,
			"icon": oAPP.path.join(oAPP.__dirname, 'img/logo.png'),
			"title":"JS file 수정 및 압축(compress)",
			"autoHideMenuBar": true,
			"partition": lfn_random(70), 
			"parent": oAPP.remote.getCurrentWindow(), 
			"webPreferences":{
				"devTools": true,
				"nodeIntegration": true,
				"contextIsolation": false,
				"nativeWindowOpen": true,
				"webSecurity": false,
				"sandbox": false
			}
		   
		};

		oAPP.remote.getCurrentWindow().webContents.closeDevTools();
		oUI5._win09 = new oAPP.remote.BrowserWindow(op);
		oUI5._win09.loadURL(`file://${oAPP.__dirname}/compress_JS/index.html`); 
		oAPP.remote.require('@electron/remote/main').enable(oUI5._win09.webContents);
		
		oUI5._win09.on('close', function(e){
            delete oUI5._win09;
			oAPP.remote.getCurrentWindow().close();
		
    	});

		oUI5._win09.webContents.on('did-finish-load', ()=> {
			oUI5._win09.show();

			if(!oAPP.remote.app.isPackaged){
				oUI5._win09.webContents.openDevTools();
			}
			
		});


    },

	//네이버 블로그 자동 등록
	onNAVER: ()=>{

		var op = {
			"height": screen.availHeight,
			"width": screen.availWidth,
			"modal":false,
			"alwaysOnTop":false,
			"fullscreen":false,
			"parent": oAPP.remote.getCurrentWindow(),
			"webPreferences":{
				"devTools": true,
				"nodeIntegration":true,
				"enableRemoteModule":true,
				"contextIsolation": false,
				"nativeWindowOpen": true,
				"webSecurity": false,
				"webviewTag":true

			}
			
		};

		oAPP.remote.getCurrentWindow().closeDevTools();

		delete oAPP._WIN;
		oAPP._WIN = new oAPP.remote.BrowserWindow(op);
		oAPP._WIN.setMenu(null);


		oAPP._WIN.loadURL(`file://${__dirname}/AutoNaverBlogWriting/index.html`);

		oAPP._WIN.webContents.on('did-finish-load', ()=> {
			
			if(!oAPP.remote.app.isPackaged){
				oAPP._WIN.openDevTools(); 
			}
			
			//번역 대상 정보 전송
			oAPP._WIN.webContents.send('IF-AUTO-NAVER-BLOG-WRITING', { TARGET: "aa" });

			oAPP._WIN.focus();


		});


		oAPP._WIN.on('close', ()=>{
			oAPP.globalShortcut.unregisterAll();
			oAPP.remote.getCurrentWindow().focus();

		});
		

		var remote = require('@electron/remote');
		remote.require('@electron/remote/main').enable(oAPP._WIN.webContents);   


	},
    
	//U4A WS3.0 SP(support package) upgrade
	onSP_UPGRADE: ()=>{

		if(typeof oUI5._win11 !== "undefined"){ return; }

		var op = {
			"height": 800,
			"width": 1200,
			"modal": false,
			"show": false,
			"minHeight":750,
			"minWidth":500,
			//"icon": oAPP.path.join(oAPP.__dirname, 'img/logo.png'),
			"title":"U4A WS3.0 SP(support package) upgrade",
			"autoHideMenuBar": true,
			"parent": oAPP.remote.getCurrentWindow(), 
			"webPreferences":{
				"devTools": true,
				"nodeIntegration": true,
				"contextIsolation": false,
				"nativeWindowOpen": true,
				"webSecurity": false
			}
		   
		};

		oAPP.remote.getCurrentWindow().webContents.closeDevTools();
		oUI5._win11 = new oAPP.remote.BrowserWindow(op);
		oUI5._win11.loadURL(`file://${oAPP.__dirname}/SupportPackageUpgrade/index.html`); 
		oAPP.remote.require('@electron/remote/main').enable(oUI5._win11.webContents);
		
		oUI5._win11.on('close', function(e){
            delete oUI5._win11;
			oAPP.remote.getCurrentWindow().close();
			//oAPP.remote.getCurrentWindow().focus();
    	});

		oUI5._win11.webContents.on('did-finish-load', ()=> {
			oUI5._win11.show();

			if(!oAPP.remote.app.isPackaged){
				oUI5._win11.openDevTools(); 
			}

		});
		

	}

    
};

//Device ready 
document.addEventListener('deviceready', onDeviceReady, false);
function onDeviceReady() {
    oAPP.onStart();
}



//랜덤키 생성
function lfn_random(length = 8){
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let str = '';
    
    for (let i = 0; i < length; i++) {
        str += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return str;
}