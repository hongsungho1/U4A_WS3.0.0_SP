var SEND_X = JSON.stringify({"body":{ "dbKey":"3832774", "strCode":"1026" }});
var xhttp = new XMLHttpRequest();

xhttp.onload = (e)=>{

    try {
        var sDATA = e.target.response; 
    } catch (err) {
        //통신 오류
        return;

    }

    //통신 오류
    if(typeof sDATA.head?.result_code === "undefined"){
       //오류
       return;

    }




};

xhttp.onerror = (e)=>{ debugger; };
xhttp.ontimeout = ()=>{ debugger;};
xhttp.open("post", "https://smo.emart.com/api/pog/selectPOGPdf", true); 
xhttp.setRequestHeader("Content-Type", "application/json");
xhttp.withCredentials = true;
xhttp.send(SEND_X);



var callPdfView = function(data) {

    var data = {
                type: "binary",
                param : data.replace(/\r\n/gi, "")
               };

    var callback = M.response.on(function(result){

    }).toString();

    M.execute("callPdfView", data, callback);

}