oAPP.lf_01 = ()=>{
    alert();

    function lfaaa(){


        
    }


}
