    //미디어 스트림 객체 생성 
    try {
        const stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: {
                mandatory: {
                    chromeMediaSource: 'desktop',
                    chromeMediaSourceId: oAPP.SCREEN_ID, //스크린 ID
                    minWidth: 600,
                    maxWidth: screen.availWidth - 200, 
                    minHeight: 500,
                    maxHeight: screen.availHeight - 100
                }
          }
        });

        _onHandleStream(stream);

    } catch (e) {
        //스트림 오류 발생시 
        _onHandleError(e);
    }


    //미디어 스트림
    async function _onHandleStream (stream) {

        //저장처리 파일명 구성  
        var fileName = "test_video.mp4";

        //저장 로컬 PC 경로         
        oAPP.FILE_PATH  = oAPP.path.join(oAPP.saveDirectory, fileName);

        //비디오 레코딩 객체 생성
        oAPP.REC = new MediaRecorder(stream);

        //비디오 레코딩 시작
        oAPP.REC.addEventListener("dataavailable", async (e) => { 

            //비디오 파일 바이너리 버퍼를 선택 PC경로에 저장 처리
            // e.data.arrayBuffer() <-- 파일 버퍼임!!!!!
            oAPP.fs.appendFile(oAPP.FILE_PATH, Buffer.from(await e.data.arrayBuffer()), function (err) {
                if (err) {return;};
                console.log('Saved!');
            });

        });

        //비디오 레코딩 스톱 이벤트 설정 
        oAPP.REC.addEventListener("stop", async (e) => { 


        });

        //레코딩 시작 - 3초에 한번씩 상위 이벤트("dataavailable") 로 Callback 여부 
        oAPP.REC.start(3000);

    }
    
    

    //미디어 오류 
    function _onHandleError (e) {


    }