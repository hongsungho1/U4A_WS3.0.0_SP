$(function(){
	var width = $("#dataDiv").outerWidth();
	$("#dataDiv" ).animate({ "right": "-="+width+"px" },"fast",function(){$( "#dataDiv").show();} );
	$("#dataDiv" ).animate({ "right": "+=20px"}, "slow");

});

var animateState = false;
var callback = function(){
	animateState = true;
};

var keepOffsetOn = function(obj){
	var offset = $(obj).offset();
	$(obj).css("left",offset.left+"px");
	$(obj).css("right","auto");
}

var keepOffsetOff = function(obj){
	var width = $(obj).outerWidth()-20;
	$(obj).css("right","-"+width+"px");
	$(obj).css("left","auto");
}


var showDataList = function(){
		$("#dataDiv").stop();
		var width = $(".dataDiv").outerWidth();
		$("#dataDiv").animate({ "right": "+="+width}, "slow" );
		$("#openDiv").attr("alt","닫기");
		$("#openDiv").attr("src","img/btn_right_c.png");
	};	
var hideDataList = function(){
		$("#dataDiv").stop();
		var width = $(".dataDiv").outerWidth();
		$("#dataDiv").animate({ "right": "-="+width}, "slow");		
		$("#openDiv").attr("alt","열기");
		$("#openDiv").attr("src","img/btn_right_o.png");
	};	

var showSearchDiv = function(){
		var height = $("#searchKeyTop").outerHeight();	
		$(".stop" ).animate({"top": "+="+height+"px" }, "slow" );
		$("#openTop").attr("alt","닫기");
		$("#openTop").attr("src","img/btn_top_c.png");
	};	
var hideSearchDiv = function(){
		var height = $("#searchKeyTop").outerHeight();
		$(".stop" ).animate({"top": "-="+height+"px" }, "slow" );
		$("#openTop").attr("alt","열기");
		$("#openTop").attr("src","img/btn_top_o.png");
	};