$(function(){

	$('#obsCode').on('change', function() {	
		setMarker(map,eval("obslonlat."+this.value).lon,eval("obslonlat."+this.value).lat)
	});

	$( "#progressbar" ).progressbar({ value: false});
});

var showSearchDiv = function(){
		var height = $("#searchKeyTop").outerHeight();	
		$(".stop" ).animate({"top": "+="+height+"px" }, "slow" );
		$("#openTop").attr("alt","닫기");
		$("#openTop").attr("src","img/btn_top_c.png");
	};	
var hideSearchDiv = function(){
		var height = $("#searchKeyTop").outerHeight();
		$(".stop" ).animate({"top": "-="+height+"px" }, "slow" );
		$("#openTop").attr("alt","열기");
		$("#openTop").attr("src","img/btn_top_o.png");
	};