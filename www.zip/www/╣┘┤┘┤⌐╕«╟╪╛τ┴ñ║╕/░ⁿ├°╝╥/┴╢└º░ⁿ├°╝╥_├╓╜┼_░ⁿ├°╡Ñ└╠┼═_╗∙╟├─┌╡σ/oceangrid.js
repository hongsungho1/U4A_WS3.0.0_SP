        var map;
        var loadEnd;
        var oloMarker; // OpenLayer Overview Marker
		var obslonlat = {
			DT_0001:{lon:126.5921,lat:37.45198},
			DT_0002:{lon:126.8227,lat:36.96686},
			DT_0003:{lon:126.4207,lat:35.42616},
			DT_0004:{lon:126.5432,lat:33.52748},
			DT_0005:{lon:129.0354,lat:35.09628},
			DT_0006:{lon:129.1163,lat:37.55036},
			DT_0007:{lon:126.3756,lat:34.77976},
			DT_0008:{lon:126.6472,lat:37.19222},
			DT_0009:{lon:129.3838,lat:36.04713},
			DT_0010:{lon:126.5616,lat:33.23995},
			DT_0011:{lon:129.4532,lat:36.67756},
			DT_0012:{lon:128.5941,lat:38.20709},
			DT_0013:{lon:130.9137,lat:37.4915},
			DT_0014:{lon:128.4347,lat:34.82768},
			DT_0015:{lon:128.5889,lat:35.21},
			DT_0016:{lon:127.7656,lat:34.74722},
			DT_0017:{lon:126.3528,lat:37.0075},
			DT_0018:{lon:126.5631,lat:35.97549},
			DT_0019:{lon:128.8109,lat:35.02418},
			DT_0020:{lon:129.3872,lat:35.50183},
			DT_0021:{lon:126.3001,lat:33.96183},
			DT_0022:{lon:126.9277,lat:33.47472},
			DT_0023:{lon:126.2512,lat:33.21433},
			DT_0024:{lon:126.6875,lat:36.00694},
			DT_0025:{lon:126.4861,lat:36.40639},
			DT_0026:{lon:127.3427,lat:34.48112},
			DT_0027:{lon:126.7596,lat:34.31551},
			DT_0028:{lon:126.3086,lat:34.37769},
			DT_0029:{lon:128.6992,lat:34.80151},
			DT_0030:{lon:126.3017,lat:35.61806},
			DT_0031:{lon:127.3089,lat:34.02843},
			DT_0032:{lon:126.5222,lat:37.73194},
			DT_0034:{lon:126.1322,lat:36.67366},
			DT_0035:{lon:125.4356,lat:34.68417},
			DT_0037:{lon:125.9848,lat:36.11729},
			DT_0038:{lon:126,lat:37.19457},
			DT_0039:{lon:129.7325,lat:36.71903},
			DT_0041:{lon:126.1683,lat:34.09846},
			DT_0042:{lon:128.3064,lat:34.70472},
			DT_0043:{lon:126.4286,lat:37.23861},
			DT_0044:{lon:126.5845,lat:37.5455},
			DT_0049:{lon:127.7548,lat:34.90367},
			DT_0050:{lon:126.2389,lat:36.91306},
			DT_0051:{lon:126.4953,lat:36.12889},
			DT_0052:{lon:126.586,lat:37.33819},
			DT_0056:{lon:128.7869,lat:35.0775},
			DT_0057:{lon:129.1439,lat:37.49472},
			DT_0058:{lon:126.6011,lat:37.56083},
			DT_0061:{lon:128.0697,lat:34.92406},
			IE_0060:{lon:125.1825,lat:32.12306},
			IE_0061:{lon:124.5928,lat:33.94193},
			IE_0062:{lon:124.738,lat:37.42318}
		};
        function init() {
			map = new OpenLayers.Map('map', {
			  theme: null,
			  controls: [
				  new OpenLayers.Control.Attribution(),
				  new OpenLayers.Control.Navigation({
					  dragPanOptions: {
						  enableKinetic: true
					  }
				  })
			  ],
			  sphericalMercator: true,
			  projection: new OpenLayers.Projection("EPSG:900913"),
			  units: "m",
			  numZoomLevels: 16,
			  maxResolution: 156543.0339,
			  maxExtent: new OpenLayers.Bounds(-20037508.34, -20037508.34, 20037508.34, 20037508.34),
			  restrictedExtent: new OpenLayers.Bounds(12823060.932019735,3248973.789650974, 15730006.674231393,5621521.486192066),
			  isValidZoomLevel : function(zoomLevel) {
							return ((zoomLevel != null) && (zoomLevel >= 6) && (zoomLevel < 16));
						}
			});

            var vWorldStreet = new OpenLayers.Layer.XYZ(
                "VWorld Street Map",
                [
					"http://xdworld.vworld.kr:8080/2d/Base/201512/${z}/${x}/${y}.png"
                ]
            );
            
			map.addLayers([vWorldStreet]);
			map.setCenter(new OpenLayers.LonLat(14243425.793355, 4302305.8698004), 7); // Zoom level
									
			var og_gd01_as = new OpenLayers.Layer.WMS(
					'og_gd01_as', 'http://www.khoa.go.kr/oceangrid/cmm/proxyRun.do?call=wms',
					{
						layers: 'geotwo_postgis:og_gd01_as', transparent: 'true' 
 						,version: '1.1.0'
					}, {
                        singleTile: true
					}
				)			
			map.addLayers([og_gd01_as]);				
			


	}//init end




 function setMarker(map,lon,lat){
	if(map.getLayersByName("markername").length != 0){
		map.removeLayer(map.getLayersByName("markername")[0]);
	}

	for(idx =0; idx < map.popups.length;idx++){
			map.removePopup(map.popups[idx]);
		}
 
	var lon_lat = new OpenLayers.Geometry.Point(lon,lat).transform(new OpenLayers.Projection("EPSG:4326"),map.projection);
	var overlay = new OpenLayers.Layer.Vector("markername", {
			styleMap: new OpenLayers.StyleMap({
				externalGraphic: 'img/icon_DT_v01.png',
				graphicWidth: 20, graphicHeight: 24, graphicYOffset: -24,
				title: ''
			})
		});

    overlay.addFeatures([
        new OpenLayers.Feature.Vector(lon_lat, {tooltip: 'OpenLayers'})
    ]);

	map.addLayers([overlay]);

 }
	
	function keepOffsetOn(obj){
		var asd = $(obj).offset();
		$(obj).css("left",asd.left+"px");
		$(obj).css("right","auto");
	}

	function keepOffsetOff(obj){
		var width = $(obj).outerWidth()-20;
		$(obj).css("right","-"+width+"px");
		$(obj).css("left","auto");
	}
 
	
	function createMetaPopup(ObsCode,data,ResultType){
		for(idx =0; idx < map.popups.length;idx++){
			map.removePopup(map.popups[idx]);
		}

		var lon = eval("obslonlat."+ObsCode).lon;
		var lat = eval("obslonlat."+ObsCode).lat;
		var content ="";
		if(data.result.data != undefined){
			if(ResultType == "json"){
				content = "<table id='metaList' name='metaList'  style='font-size:.7em'>";
				content += "<tr><th>고정 관측소 ID</th><td>"+	data.result.meta.obs_post_id+"</td></tr>"; 
				content += "<tr><th>고정 관측소 명</th><td>"+data.result.meta.obs_post_name+"</td></tr>"; 
				content += "<tr><th>고정 관측소 위도</th><td>"+data.result.meta.obs_lat+"</td></tr>"; 
				content += "<tr><th>고정 관측소 경도</th><td>"+data.result.meta.obs_lon+"</td></tr>"; 
				content += "<tr><th>금일요청가능횟수</th><td>"+data.result.meta.obs_last_req_cnt+"</td></tr>"; 
				content +="<tr><td colspan =2 style='border-left:none;border-right:none;'></td></tr>";				
				content += "<tr><th>관측시간</th><td>"+data.result.data.record_time+"</td></tr>"; 
				content += "<tr><th>풍속</th><td>"+data.result.data.wind_speed+"</td></tr>"; 
				content += "<tr><th>돌풍</th><td>"+data.result.data.wind_gust+"</td></tr>"; 
				content += "<tr><th>풍향</th><td>"+data.result.data.wind_dir+"</td></tr>"; 
				content += "<tr><th>기온</th><td>"+data.result.data.air_temp+"</td></tr>"; 
				content += "<tr><th>기압</th><td>"+data.result.data.air_press+"</td></tr>"; 
				content += "<tr><th>수온</th><td>"+data.result.data.water_temp+"</td></tr>"; 
				content += "<tr><th>조위</th><td>"+data.result.data.tide_level+"</td></tr>"; 
				content += "<tr><th>염분</th><td>"+data.result.data.Salinity+"</td></tr>"; 
				content += "</table>"; 	
			}else if(ResultType == "xml"){
				content = "<table id='metaList' name='metaList'  style='font-size:.7em'>";
				content += "<tr><th>고정 관측소 ID</th><td>"+	$(data).find("result").find("meta").find("obs_post_id").text()+"</td></tr>"; 
				content += "<tr><th>고정 관측소 명</th><td>"+$(data).find("result").find("meta").find("obs_post_name").text()+"</td></tr>"; 
				content += "<tr><th>고정 관측소 위도</th><td>"+$(data).find("result").find("meta").find("obs_lat").text()+"</td></tr>"; 
				content += "<tr><th>고정 관측소 경도</th><td>"+$(data).find("result").find("meta").find("obs_lon").text()+"</td></tr>"; 
				content += "<tr><th>금일요청가능횟수</th><td>"+$(data).find("result").find("meta").find("obs_last_req_cnt").text()+"</td></tr>";
				content +="<tr><td colspan =2 style='border-left:none;border-right:none;'></td></tr>";
				content += "<tr><th>풍속</th><td>"+$(data).find("result").find("data").find("record_time").text()+"</td></tr>";
				content += "<tr><th>풍속</th><td>"+$(data).find("result").find("data").find("wind_speed").text()+"</td></tr>"; 
				content += "<tr><th>돌풍</th><td>"+$(data).find("result").find("data").find("wind_gust").text()+"</td></tr>"; 
				content += "<tr><th>풍향</th><td>"+$(data).find("result").find("data").find("wind_dir").text()+"</td></tr>"; 
				content += "<tr><th>기온</th><td>"+$(data).find("result").find("data").find("air_temp").text()+"</td></tr>"; 
				content += "<tr><th>기압</th><td>"+$(data).find("result").find("data").find("air_press").text()+"</td></tr>"; 
				content += "<tr><th>수온</th><td>"+$(data).find("result").find("data").find("water_temp").text()+"</td></tr>"; 
				content += "<tr><th>조위</th><td>"+$(data).find("result").find("data").find("tide_level").text()+"</td></tr>"; 
				content += "<tr><th>염분</th><td>"+$(data).find("result").find("data").find("Salinity").text()+"</td></tr>";
				content += "</table>";
			}
			var popup = new OpenLayers.Popup.FramedCloud(ObsCode, 
				new OpenLayers.Geometry.Point(lon,lat).transform(new OpenLayers.Projection("EPSG:4326"),map.projection).getBounds().getCenterLonLat(), null
				,content
				,null
				,false 
			);
			map.addPopup(popup);
		}else{
			alert("검색된 데이터가 없습니다.");
		}
	}