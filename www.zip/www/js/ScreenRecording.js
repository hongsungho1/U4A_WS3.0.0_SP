/* ================================================================= */
// 설치 npm 
// npm install mime-types
/* ================================================================= */
const desktopCapturer = oAPP.remote.require('electron').desktopCapturer;

/* ================================================================= */
/* 내부 펑션 
/* ================================================================= */

/*================================================= */
/*  레코드 스트리밍 Callback  */
/*================================================= */
function _onHandleStream (stream) {
    

    chunks = [];

    const video = document.querySelector('video')
    video.srcObject = stream;
    video.onloadedmetadata = (e) => video.play();
    
    REC = new MediaRecorder(stream);

    var III = 0;

    REC.addEventListener("dataavailable", async (e) => { 

        chunks.push(e.data);
        var bbb = Buffer.from(await e.data.arrayBuffer());
        
        //oAPP.fs.appendFile('F:\\cordova_u4a\\electron\\U4A_HTTP_CLIENT_SERVER\\xxxx.webm', bbb, function (err) {
        oAPP.fs.appendFile('F:\\cordova_u4a\\electron\\U4A_HTTP_CLIENT_SERVER\\zzzz.mp4', bbb, function (err) {
            if (err) throw err;
            console.log('Saved!');
        });

        return;

        if(III != 0){ return; }
        III++;
        GGGG =e.data;
        var bbb = Buffer.from(await e.data.arrayBuffer());
        oAPP.fs.writeFileSync("F:\\cordova_u4a\\electron\\U4A_HTTP_CLIENT_SERVER\\xxxx.webm", bbb, null, function(err){ console.error(">> : " + err); });


    });


    REC.addEventListener("stop", async (e) => { 




        debugger;
        return;

        const byteArray = new Uint8Array(chunks);

        const blob = new Blob(chunks);
        oAPP.fs.writeFileSync("F:\\cordova_u4a\\electron\\U4A_HTTP_CLIENT_SERVER\\xxxx.mp4", byteArray , null, function(err){});

        return;

        let writer = oAPP.fs.createWriteStream("F:\\cordova_u4a\\electron\\U4A_HTTP_CLIENT_SERVER\\xxxx.mp4");
        writer.write(chunks);
        return;

       
        //audioURL = window.URL.createObjectURL(blob);

    
    });


    //https://developer.mozilla.org/en-US/docs/Web/API/MediaRecorder/dataavailable_event
    REC.start(1000);

    //REC.stop();





}


  
/*================================================= */
/*  랜덤키 생성  */
/*================================================= */
function _onHandleError (e) {
    console.log(e)
}


/* ================================================================= */
// 사용 예시 
// var ret = require(oAPP.path.join(__dirname, 'js/ScreenRecording.js'));
//     ret.start({});
//     ret.stop({});                  
// 
/* ================================================================= */

/* ================================================================= */
/* Export Module Function - 스크린 레코딩 시작
/* ================================================================= */
exports.start = async function(sParams){
    return new Promise((resolve, reject) => {

        desktopCapturer.getSources({ types: ['window', 'screen'] }).then(async sources => {
            
            for (const source of sources) {
                console.log(source.id);
                console.log(source.thumbnail.toDataURL());
                
                break;
                
            }

            try {
                const stream = await navigator.mediaDevices.getUserMedia({
                    audio: false,
                    video: {
                        mandatory: {
                            chromeMediaSource: 'desktop',
                            chromeMediaSourceId: sources[0].id,
                            minWidth: 1280,
                            maxWidth: 1280,
                            minHeight: 720,
                            maxHeight: 720
                        }
                  }
                });

                _onHandleStream(stream);

            } catch (e) {
                _onHandleError(e)
            }

            //resolve();

        });



    });
};



/* ================================================================= */
/* Export Module Function - 스크린 레코딩 시작
/* ================================================================= */
exports.stop = async function(sParams){
    return new Promise((resolve, reject) => {





    });
};