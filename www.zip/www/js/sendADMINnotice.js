/* ================================================================= */
// 설치 npm 
// npm install mime-types
// npm install node-ssh
/* ================================================================= */

/* ================================================================= */
// I/F 필드 정의 
/* ================================================================= */
/*
var TY_IFDATA = {

    "TITLE": "",      //제목 
    "TYPE" : "",      //문서 유형
    "DESC" : "",      //내역 
    "SAMPLE_URL": "", //샘플 URL
    "IMAGE": {
       "URL" :"",     //대표 이미지 URL
       "FPATH": "",   //대표 이미지 local path
       "T_URL":[],    //서브 이미지 URL 
       "DATA": ""     //대표 이미지 Data (Base64)
    },
    "VIDEO": {
       "URL"  : "",   //동영상 URL 
       "FPATH": ""    //동영상 path(PC 디렉토리 경로)
    },
    "HASHTAG" : []    //해시태그
};
*/
/* ================================================================= */


/* ================================================================= */
/* 사용 예시 
    var sendADMINnotice = require(oAPP.path.join(__dirname, 'js/sendADMINnotice.js'));
    var retdata = await sendADMINnotice.send(oAPP.remote, "TEMP");
    retdata.RETCD <-- E:오류 
    retdata.RTMSG <-- 처리 메시지 
      
*/
/* ================================================================= */


/* ================================================================= */
/* 내부 전역 변수 
/* ================================================================= */

let BOT = null;
let TELEGRAMKEY = "5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ";

var T_ADMIN = [];
    T_ADMIN.push("2142197003");  //홍영선
    T_ADMIN.push("5311179178");  //홍성호
    T_ADMIN.push("2141804045");  //박은섭
    T_ADMIN.push("498542502");   //이청윤

/* ================================================================= */
/* 내부 펑션 
/* ================================================================= */

//템플릿 
async function _temp(REMOTE, RESOLVE){

    var LMSG = " 😡 서비스 가동 완료!!!";

    for (let i = 0; i < T_ADMIN.length; i++) {
        var S_ADMIN = T_ADMIN[i];
        
        //이미지 + 텍스트 전송 방식
        //await oAPP.BOT.sendPhoto(S_USER, "https://www.u4ainfo.com/u4a_sample/img/error-page.png",{caption: LMSG});

        //메시지 전송 방식
        await BOT.sendMessage(S_ADMIN, LMSG);

    }

    RESOLVE({RETCD:"S", RTMSG:"처리 완료!!"});

}


/* ================================================================= */
/* Export Module Function 
/* ================================================================= */
exports.send = async function(REMOTE, PRCCD){

    return new Promise((resolve, reject) => {
        debugger;

        if(BOT == null){
            var TelegramBot = REMOTE.require('node-telegram-bot-api');
            BOT = new TelegramBot(TELEGRAMKEY , { polling: false });

        }

        //처리 프로세스 코드에 따른 분기
        switch (PRCCD) {
            case "TEMP": //샘플
                _temp(REMOTE, resolve);
                
                break;
        
            default:
                resolve({RETCD:"E", RTMSG:"처리 유형 오류"});
                break;
        }

    });

};